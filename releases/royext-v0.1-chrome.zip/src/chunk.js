(self.webpackChunkscriptcat=self.webpackChunkscriptcat||[]).push([["411"],{76729(e){"use strict";e.exports=`// @copyright https://github.com/silverwzw/Tampermonkey-Typescript-Declaration

declare const unsafeWindow: Window;

declare type ConfigType = "text" | "checkbox" | "select" | "mult-select" | "number" | "textarea" | "time";

declare interface Config {
  [key: string]: unknown;
  title: string;
  description: string;
  default?: unknown;
  type?: ConfigType;
  bind?: string;
  values?: unknown[];
  password?: boolean;
  // 文本类型时是字符串长度,数字类型时是最大值
  max?: number;
  min?: number;
  rows?: number; // textarea行数
  index: number; // 配置项排序位置
}

declare type UserConfig = { [key: string]: { [key: string]: Config } };

declare const GM_info: {
  version: string;
  scriptWillUpdate: boolean;
  scriptHandler: "ScriptCat";
  scriptUpdateURL?: string;
  // scriptSource: string;
  scriptMetaStr?: string;
  userConfig?: UserConfig;
  userConfigStr?: string;
  isIncognito: boolean;
  sandboxMode: "raw"; // "js" | "raw" | "none";
  userAgentData: {
    brands?: {
      brand: string;
      version: string;
    }[];
    mobile?: boolean;
    platform?: string;
    architecture?: string;
    bitness?: string;
  };
  downloadMode: "native"; // "native" | "disabled" | "browser";
  script: {
    author?: string;
    description?: string;
    // excludes: string[];
    grant: string[];
    header: string;
    // homepage?: string;
    icon?: string;
    icon64?: string;
    includes?: string[];
    // lastModified: number;
    matches: string[];
    name: string;
    namespace?: string;
    // position: number;
    "run-at": string;
    "run-in": string[];
    // resources: string[];
    // unwrap: boolean;
    version: string;
    /* options: {
      awareOfChrome: boolean;
      run_at: string;
      noframes?: boolean;
      compat_arrayLeft: boolean;
      compat_foreach: boolean;
      compat_forvarin: boolean;
      compat_metadata: boolean;
      compat_uW_gmonkey: boolean;
      override: {
        orig_excludes: string[];
        orig_includes: string[];
        use_includes: string[];
        use_excludes: string[];
        [key: string]: any;
      };
      [key: string]: any;
    }; */
    [key: string]: unknown;
  };
  [key: string]: unknown;
};

declare function GM_listValues(): string[];

declare function GM_addValueChangeListener(name: string, listener: GMTypes.ValueChangeListener): number;

declare function GM_removeValueChangeListener(listenerId: number): void;

declare function GM_setValue(name: string, value: any): void;
// 设置多个值, values是一个对象, 键为值的名称, 值为值的内容
declare function GM_setValues(values: { [key: string]: any }): void;

declare function GM_getValue(name: string, defaultValue?: any): any;

// 获取多个值, 如果keysOrDefaults是一个对象, 则使用对象的值作为默认值
declare function GM_getValues(keysOrDefaults: { [key: string]: any } | string[] | null | undefined): {
  [key: string]: any;
};

declare function GM_deleteValue(name: string): void;

// 删除多个值, names是一个字符串数组
declare function GM_deleteValues(names: string[]): void;

// 支持level和label
declare function GM_log(message: string, level?: GMTypes.LoggerLevel, labels?: GMTypes.LoggerLabel): void;

declare function GM_getResourceText(name: string): string | undefined;

declare function GM_getResourceURL(name: string, isBlobUrl?: boolean): string | undefined;

function GM_registerMenuCommand(
  name: string,
  listener?: (inputValue?: any) => void,
  options_or_accessKey?:
    | {
        id?: number | string;
        accessKey?: string; // 菜单快捷键
        autoClose?: boolean; // 默认为 true，false 时点击后不关闭弹出菜单页面
        nested?: boolean; // SC特有配置，默认为 true，false 的话浏览器右键菜单项目由三级菜单升至二级菜单
        individual?: boolean; // SC特有配置，默认为 false，true 表示相同的菜单项不合并显示
      }
    | string
): number;

declare function GM_unregisterMenuCommand(id: number): void;

/**
 * 注册一个菜单输入框, 允许用户输入值, 并在输入完成后用回调函数
 */
declare function CAT_registerMenuInput(
  name: string,
  listener?: (inputValue?: any) => void,
  options_or_accessKey?:
    | {
        id?: number | string;
        accessKey?: string; // 菜单快捷键
        autoClose?: boolean; // 默认为 true，false 时点击后不关闭弹出菜单页面
        nested?: boolean; // SC特有配置，默认为 true，false 的话浏览器右键菜单项目由三级菜单升至二级菜单
        individual?: boolean; // SC特有配置，默认为 false，true 表示相同的菜单项不合并显示
        // 可选输入框
        inputType?: "text" | "number" | "boolean";
        title?: string; // title 只适用于输入框类型
        inputLabel?: string;
        inputDefaultValue?: string | number | boolean;
        inputPlaceholder?: string;
      }
    | string
): number;

declare const CAT_unregisterMenuInput: typeof GM_unregisterMenuCommand;

/**
 * 当使用 @early-start 时，可以使用此函数来等待脚本完全加载完成
 */
declare function CAT_scriptLoaded(): Promise<void>;

declare function GM_openInTab(url: string, options: GMTypes.OpenTabOptions): GMTypes.Tab | undefined;
declare function GM_openInTab(url: string, loadInBackground: boolean): GMTypes.Tab | undefined;
declare function GM_openInTab(url: string): GMTypes.Tab | undefined;

declare function GM_xmlhttpRequest(details: GMTypes.XHRDetails): GMTypes.AbortHandle<void>;

declare function GM_download(details: GMTypes.DownloadDetails<string | Blob | File>): GMTypes.AbortHandle<boolean>;
declare function GM_download(url: string, filename: string): GMTypes.AbortHandle<boolean>;

declare function GM_getTab(callback: (tab: object) => void): void;

declare function GM_saveTab(tab: object): Promise<void>;

declare function GM_getTabs(callback: (tabs: { [key: number]: object }) => void): void;

declare function GM_notification(details: GMTypes.NotificationDetails, ondone?: GMTypes.NotificationOnDone): void;
declare function GM_notification(
  text: string,
  title: string,
  image: string,
  onclick?: GMTypes.NotificationOnClick
): void;

declare function GM_closeNotification(id: string): void;

declare function GM_updateNotification(id: string, details: GMTypes.NotificationDetails): void;

declare function GM_setClipboard(data: string, info?: string | { type?: string; mimetype?: string }): void;

declare function GM_addElement(tag: string, attributes: Record<string, string | number | boolean>): HTMLElement;
declare function GM_addElement(
  parentNode: Node,
  tag: string,
  attrs: Record<string, string | number | boolean>
): HTMLElement;

declare function GM_addStyle(css: string): HTMLStyleElement;

// name和domain不能都为空
declare function GM_cookie(
  action: GMTypes.CookieAction,
  details: GMTypes.CookieDetails,
  ondone: (cookie: GMTypes.Cookie[], error: unknown | undefined) => void
): void;
 
/**
 * GM.* API (兼容 Greasemonkey4/Tampermonkey 4+ 的 Promise 风格)
 */
declare const GM: {
  /** 脚本信息 */
  readonly info: typeof GM_info;

  /** 获取一个值 */
  getValue<T = any>(name: string, defaultValue?: T): Promise<T>;

  /** 获取多个值, 如果keysOrDefaults是一个对象, 则使用对象的值作为默认值 */
  getValues(keysOrDefaults: { [key: string]: any } | string[] | null | undefined): Promise<{ [key: string]: any }>;

  /** 设置一个值 */
  setValue(name: string, value: any): Promise<void>;

  /** 设置多个值, values是一个对象, 键为值的名称, 值为值的内容 */
  setValues(values: { [key: string]: any }): Promise<void>;

  /** 删除一个值 */
  deleteValue(name: string): Promise<void>;

  /** 删除多个值, names是一个字符串数组 */
  deleteValues(names: string[]): Promise<void>;

  /** 获取所有已保存值的 key 列表 */
  listValues(): Promise<string[]>;

  /** 值变更监听 */
  addValueChangeListener(name: string, listener: GMTypes.ValueChangeListener): Promise<number>;
  removeValueChangeListener(listenerId: number): Promise<void>;

  /** 支持level和label */
  log(message: string, level?: GMTypes.LoggerLevel, labels?: GMTypes.LoggerLabel): Promise<void>;

  /** 获取资源文本 */
  getResourceText(name: string): Promise<string | undefined>;

  /** 获取资源URL */
  getResourceURL(name: string, isBlobUrl?: boolean): Promise<string | undefined>;

  /** 注册菜单 */
  registerMenuCommand(
    name: string,
    listener?: (inputValue?: any) => void,
    options_or_accessKey?:
      | {
          id?: number | string;
          accessKey?: string; // 菜单快捷键
          autoClose?: boolean; // 默认为 true
          title?: string; // 菜单提示
          // ScriptCat 扩展
          icon?: string; // 菜单图标
          // ScriptCat 扩展
          closeOnClick?: boolean; // 点击菜单后是否关闭, 与autoClose含义相同
        }
      | string
  ): Promise<number | string | undefined>;

  /** 注销菜单 */
  unregisterMenuCommand(id: number | string): Promise<void>;

  /** 样式注入 */
  addStyle(css: string): Promise<HTMLStyleElement>;

  /** 通知 */
  notification(details: GMTypes.NotificationDetails, ondone?: GMTypes.NotificationOnDone): Promise<void>;
  notification(text: string, title: string, image: string, onclick?: GMTypes.NotificationOnClick): Promise<void>;
  closeNotification(id: string): Promise<void>;
  updateNotification(id: string, details: GMTypes.NotificationDetails): Promise<void>;

  /** 设置剪贴板 */
  setClipboard(data: string, info?: string | { type?: string; mimetype?: string }): Promise<void>;

  /** 添加元素 */
  addElement(tag: string, attributes: Record<string, string | number | boolean>): Promise<HTMLElement>;
  addElement(parentNode: Node, tag: string, attrs: Record<string, string | number | boolean>): Promise<HTMLElement>;

  /** XMLHttpRequest */
  xmlHttpRequest(details: GMTypes.XHRDetails): Promise<GMTypes.XHRResponse>;

  /** 下载 */
  download(details: GMTypes.DownloadDetails<string | Blob | File>): Promise<boolean>;
  download(url: string, filename: string): Promise<boolean>;

  /** Tab 存储 */
  getTab(): Promise<object>;
  saveTab(tab: object): Promise<void>;
  getTabs(): Promise<{ [key: number]: object }>;

  /** 打开新标签页 */
  openInTab(url: string, options: GMTypes.OpenTabOptions): Promise<GMTypes.Tab | undefined>;
  openInTab(url: string, loadInBackground: boolean): Promise<GMTypes.Tab | undefined>;
  openInTab(url: string): Promise<GMTypes.Tab | undefined>;

  /** Cookie 操作 */
  cookie(action: GMTypes.CookieAction, details: GMTypes.CookieDetails): Promise<GMTypes.Cookie[]>;
};

/**
 * 设置浏览器代理
 * @deprecated 正式版中已废弃,后续可能会在beta版本中添加
 */
declare function CAT_setProxy(rule: CATType.ProxyRule[] | string): void;

/**
 * 清理所有代理规则
 * @deprecated 正式版中已废弃,后续可能会在beta版本中添加
 */
declare function CAT_clearProxy(): void;

/**
 * 输入x、y,模拟真实点击
 * @deprecated 正式版中已废弃,后续可能会在beta版本中添加
 */
declare function CAT_click(x: number, y: number): void;

/**
 * 打开脚本的用户配置页面
 */
declare function CAT_userConfig(): void;

/**
 * 操控管理器设置的储存系统,将会在目录下创建一个app/uuid目录供此 API 使用,如果指定了baseDir参数,则会使用baseDir作为基础目录
 * 上传时默认覆盖同名文件
 * @param action 操作类型 list 列出指定目录所有文件, upload 上传文件, download 下载文件, delete 删除文件, config 打开配置页, 暂时不提供move/mkdir等操作
 * @param details
 */
declare function CAT_fileStorage(
  action: "list",
  details: {
    // 文件路径
    path?: string;
    // 基础目录,如果未设置,则将脚本uuid作为目录
    baseDir?: string;
    onload?: (files: CATType.FileStorageFileInfo[]) => void;
    onerror?: (error: CATType.FileStorageError) => void;
  }
): void;
declare function CAT_fileStorage(
  action: "download",
  details: {
    file: CATType.FileStorageFileInfo; // 某些平台需要提供文件的hash值,所以需要传入文件信息
    onload: (data: Blob) => void;
    // onprogress?: (progress: number) => void;
    onerror?: (error: CATType.FileStorageError) => void;
    // public?: boolean;
  }
): void;
declare function CAT_fileStorage(
  action: "delete",
  details: {
    path: string;
    onload?: () => void;
    onerror?: (error: CATType.FileStorageError) => void;
    // public?: boolean;
  }
): void;
declare function CAT_fileStorage(
  action: "upload",
  details: {
    path: string;
    // 基础目录,如果未设置,则将脚本uuid作为目录
    baseDir?: string;
    data: Blob;
    onload?: () => void;
    // onprogress?: (progress: number) => void;
    onerror?: (error: CATType.FileStorageError) => void;
    // public?: boolean;
  }
): void;
declare function CAT_fileStorage(action: "config"): void;

/**
 * 脚本猫后台脚本重试, 当你的脚本出现错误时, 可以reject返回此错误, 以便脚本猫重试
 * 重试时间请注意不要与脚本执行时间冲突, 否则可能会导致重复执行, 最小重试时间为5s
 * @class CATRetryError
 */
declare class CATRetryError {
  /**
   * constructor 构造函数
   * @param {string} message 错误信息
   * @param {number} seconds x秒后重试, 单位秒
   */
  constructor(message: string, seconds: number);

  /**
   * constructor 构造函数
   * @param {string} message 错误信息
   * @param {Date} date 重试时间, 指定时间后重试
   */
  constructor(message: string, date: Date);
}

declare namespace CATType {
  interface ProxyRule {
    proxyServer: ProxyServer;
    matchUrl: string[];
  }

  type ProxyScheme = "http" | "https" | "quic" | "socks4" | "socks5";

  interface ProxyServer {
    scheme?: ProxyScheme;
    host: string;
    port?: number;
  }

  interface FileStorageError {
    // 错误码 -1 未知错误 1 用户未配置文件储存源 2 文件储存源配置错误 3 路径不存在
    // 4 上传失败 5 下载失败 6 删除失败 7 不允许的文件路径 8 网络类型的错误
    code: -1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
    error: string;
  }

  interface FileStorageFileInfo {
    // 文件名
    name: string;
    // 文件路径
    path: string;
    // 储存空间绝对路径
    absPath: string;
    // 文件大小
    size: number;
    // 文件摘要
    digest: string;
    // 文件创建时间
    createtime: number;
    // 文件修改时间
    updatetime: number;
  }

  type CATFileStorageDetails = {
    baseDir: string;
    path: string;
    filename: any;
    file: FileStorageFileInfo;
    data?: string;
  };
}

declare namespace GMTypes {
  type CookieAction = "list" | "delete" | "set";

  type LoggerLevel = "debug" | "info" | "warn" | "error";

  type LoggerLabel = {
    [key: string]: string | boolean | number | undefined;
  };

  interface CookieDetailsPartitionKeyType {
    topLevelSite?: string;
  }

  interface CookieDetails {
    url?: string;
    name?: string;
    value?: string;
    domain?: string;
    path?: string;
    secure?: boolean;
    session?: boolean;
    httpOnly?: boolean;
    expirationDate?: number;
    partitionKey?: CookieDetailsPartitionKeyType;
  }

  interface Cookie {
    domain: string;
    name: string;
    value: string;
    session: boolean;
    hostOnly: boolean;
    expirationDate?: number;
    path: string;
    httpOnly: boolean;
    secure: boolean;
    sameSite: "unspecified" | "no_restriction" | "lax" | "strict";
  }

  // tabid是只有后台脚本监听才有的参数
  type ValueChangeListener = (
    name: string,
    oldValue: unknown,
    newValue: unknown,
    remote: boolean,
    tabid?: number
  ) => unknown;

  interface OpenTabOptions {
    /**
     * 决定新标签页是否在打开时获得焦点。
     *
     * - \`true\` → 新标签页会立即切换到前台。
     * - \`false\` → 新标签页在后台打开，不会打断当前页面的焦点。
     *
     * 默认值：true
     */
    active?: boolean;

    /**
     * 决定新标签页插入位置。
     *
     * - 如果是 \`boolean\`：
     *   - \`true\` → 插入在当前标签页之后。
     *   - \`false\` → 插入到窗口末尾。
     * - 如果是 \`number\`：
     *   - \`0\` → 插入到当前标签前一格。
     *   - \`1\` → 插入到当前标签后一格。
     *
     * 默认值：true
     */
    insert?: boolean | number;

    /**
     * 决定是否设置父标签页（即 \`openerTabId\`）。
     *
     * - \`true\` → 浏览器能追踪由哪个标签打开的子标签，
     *   有助于某些扩展（如标签树管理器）识别父子关系。
     *
     * 默认值：true
     */
    setParent?: boolean;

    /**
     * 是否在隐私窗口（无痕模式）中打开标签页。
     *
     * 注意：ScriptCat 的 manifest.json 配置了 \`"incognito": "split"\`，
     * 在 normal window 中执行时，tabId/windowId 将不可用，
     * 只能执行「打开新标签页」动作。
     *
     * 默认值：false
     */
    incognito?: boolean;

    /**
     * 历史兼容字段，仅 TM 支持。
     * 语义与 \`active\` **相反**：
     *
     * - \`true\` → 等价于 \`active = false\`（后台加载）。
     * - \`false\` → 等价于 \`active = true\`（前台加载）。
     *
     * ⚠️ 不推荐使用：与 \`active\` 功能重复且容易混淆。
     *
     * 默认值：false
     * @deprecated 请使用 \`active\` 替代
     */
    loadInBackground?: boolean;

    /**
     * 是否将新标签页固定（pin）在浏览器标签栏左侧。
     *
     * - \`true\` → 新标签页为固定状态。
     * - \`false\` → 普通标签页。
     *
     * 默认值：false
     */
    pinned?: boolean;

    /**
     * 使用 \`window.open\` 打开新标签，而不是 \`chrome.tabs.create\`
     * 在打开一些特殊协议的链接时很有用，例如 \`vscode://\`, \`m3u8dl://\`
     * 其他参数在这个打开方式下无效
     *
     * 相关：Issue #178 #1043
     * 默认值：false
     */
    useOpen?: boolean;
  }

  type SWOpenTabOptions = OpenTabOptions & Required<Pick<OpenTabOptions, "active">>;

  /**
   * XMLHttpRequest readyState 状态值
   * @see https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/readyState
   */
  type ReadyState =
    | 0 // UNSENT
    | 1 // OPENED
    | 2 // HEADERS_RECEIVED
    | 3 // LOADING
    | 4; // DONE

  interface XHRResponse {
    finalUrl?: string;
    readyState?: ReadyState;
    responseHeaders?: string;
    status?: number;
    statusText?: string;
    response?: string | Blob | ArrayBuffer | Document | ReadableStream<Uint8Array<ArrayBufferLike>> | null | undefined;
    responseText?: string | undefined;
    responseXML?: Document | null | undefined;
    responseType?: "text" | "arraybuffer" | "blob" | "json" | "document" | "stream" | "";
  }

  interface XHRProgress extends XHRResponse {
    done: number;
    lengthComputable: boolean;
    loaded: number;
    position?: number;
    total: number;
    totalSize: number;
  }

  type Listener<OBJ> = (event: OBJ) => unknown;
  type ContextType = unknown;

  type GMXHRDataType = string | Blob | File | BufferSource | FormData | URLSearchParams;

  interface XHRDetails {
    method?: "GET" | "HEAD" | "POST" | "PUT" | "DELETE" | "PATCH" | "OPTIONS";
    url: string | URL | File | Blob;
    headers?: { [key: string]: string };
    data?: GMXHRDataType;
    cookie?: string;
    binary?: boolean;
    timeout?: number;
    context?: ContextType;
    responseType?: "text" | "arraybuffer" | "blob" | "json" | "document" | "stream"; // stream 在当前版本是一个较为简陋的实现
    overrideMimeType?: string;
    anonymous?: boolean;
    mozAnon?: boolean; // 发送请求时不携带cookie (兼容Greasemonkey)
    fetch?: boolean;
    user?: string;
    password?: string;
    nocache?: boolean;
    revalidate?: boolean; // 强制重新验证缓存内容：允许缓存，但必须在使用缓存内容之前重新验证
    redirect?: "follow" | "error" | "manual"; // 为了与tm保持一致, 在v0.17.0后废弃maxRedirects, 使用redirect替代, 会强制使用fetch模式
    cookiePartition?: Record<string, any> & {
      topLevelSite?: string; // 表示分区 cookie 的顶部帧站点
    }; // 包含用于发送和接收的分区 cookie 的分区键 https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/cookies#storage_partitioning
    context?: any; // 自定义值，传递给响应的 response.context 属性

    onload?: Listener<XHRResponse>;
    onloadstart?: Listener<XHRResponse>;
    onloadend?: Listener<XHRResponse>;
    onprogress?: Listener<XHRProgress>;
    onreadystatechange?: Listener<XHRResponse>;
    ontimeout?: Listener<XHRResponse>;
    onabort?: Listener<XHRResponse>;
    onerror?: (err: string | (XHRResponse & { error: string })) => void;
  }

  interface AbortHandle<RETURN_TYPE> {
    abort(): RETURN_TYPE;
  }

  interface DownloadError {
    error: "not_enabled" | "not_whitelisted" | "not_permitted" | "not_supported" | "not_succeeded" | "unknown";
    details?: string;
  }

  interface DownloadDetails<URL> {
    // TM/SC 标准参数
    url: URL;
    name: string;
    headers?: { [key: string]: string };
    saveAs?: boolean;
    conflictAction?: "uniquify" | "overwrite" | "prompt";

    // 其他参数
    timeout?: number; // SC/VM
    anonymous?: boolean; // SC/VM
    context?: ContextType; // SC/VM
    user?: string; // SC/VM
    password?: string; // SC/VM

    method?: "GET" | "POST"; // SC
    downloadMode?: "native" | "browser"; // SC
    cookie?: string; // SC

    // TM/SC 标准回调
    onload?: Listener<object>;
    onerror?: Listener<DownloadError>;
    onprogress?: Listener<{
      done: number;
      lengthComputable: boolean;
      loaded: number;
      position?: number;
      total: number;
      totalSize: number;
    }>;
    ontimeout?: (arg1?: any) => void;
  }

  interface NotificationThis extends NotificationDetails {
    id: string;
  }

  type NotificationOnClickEvent = {
    event: "click" | "buttonClick";
    id: string;
    isButtonClick: boolean;
    buttonClickIndex: number | undefined;
    byUser: boolean | undefined;
    preventDefault: () => void;
    highlight: NotificationDetails["highlight"];
    image: NotificationDetails["image"];
    silent: NotificationDetails["silent"];
    tag: NotificationDetails["tag"];
    text: NotificationDetails["tag"];
    timeout: NotificationDetails["timeout"];
    title: NotificationDetails["title"];
    url: NotificationDetails["url"];
  };
  type NotificationOnClick = (this: NotificationThis, event: NotificationOnClickEvent) => unknown;
  type NotificationOnDone = (this: NotificationThis, user?: boolean) => unknown;

  interface NotificationButton {
    title: string;
    iconUrl?: string;
  }

  interface NotificationDetails {
    text?: string;
    title?: string;
    tag?: string;
    image?: string;
    highlight?: boolean;
    silent?: boolean;
    timeout?: number;
    url?: string;
    onclick?: NotificationOnClick;
    ondone?: NotificationOnDone;
    progress?: number;
    oncreate?: NotificationOnClick;
    // 只能存在2个
    buttons?: NotificationButton[];
  }

  interface Tab {
    close(): void;
    onclose?: () => void;
    closed?: boolean;
    name?: string;
  }

  type GMClipboardInfo = string | { type?: string; mimetype?: string };
}
`},27247(e,t,r){let n=r(23352);e.exports={compatMap:{CAT_userConfig:[{type:"scriptcat",versionConstraint:">=0.11.0-beta"}],CAT_fileStorage:[{type:"scriptcat",versionConstraint:">=0.11.0"}],CAT_registerMenuInput:[{type:"scriptcat",versionConstraint:">=0.17.0-beta.2"}],CAT_unregisterMenuInput:[{type:"scriptcat",versionConstraint:">=0.17.0-beta.2"}],CAT_scriptLoaded:[{type:"scriptcat",versionConstraint:">=1.1.0-beta"}],...n.compatMap},gmPolyfillOverride:{...n.gmPolyfillOverride}}},36407(e,t,r){let n=r(48912);e.exports={compatMap:{...n.compatMap,nonFunctional:{...n.compatMap.nonFunctional,background:[],crontab:[],cloudCat:[],cloudServer:[],exportValue:[],exportCookie:[],scriptUrl:[],storageName:[],"early-start":[],"require-css":[]}}}},14845(e,t,r){"use strict";r.d(t,{s:()=>o});let{configs:n}=r(55596),i={parserOptions:{ecmaVersion:"latest",sourceType:"script",ecmaFeatures:{globalReturn:!0}},globals:{CATRetryError:"readonly",CAT_fileStorage:"readonly",CAT_userConfig:"readonly",CAT_registerMenuInput:"readonly",CAT_unregisterMenuInput:"readonly",CAT_scriptLoaded:"readonly"},rules:{"constructor-super":["error"],"for-direction":["error"],"getter-return":["error"],"no-async-promise-executor":["error"],"no-case-declarations":["error"],"no-class-assign":["error"],"no-compare-neg-zero":["error"],"no-cond-assign":["error"],"no-const-assign":["error"],"no-constant-condition":["error"],"no-control-regex":["error"],"no-debugger":["error"],"no-delete-var":["error"],"no-dupe-args":["error"],"no-dupe-class-members":["error"],"no-dupe-else-if":["error"],"no-dupe-keys":["error"],"no-duplicate-case":["error"],"no-empty":["error"],"no-empty-character-class":["error"],"no-empty-pattern":["error"],"no-ex-assign":["error"],"no-extra-boolean-cast":["error"],"no-extra-semi":["error"],"no-fallthrough":["error"],"no-func-assign":["error"],"no-global-assign":["error"],"no-import-assign":["error"],"no-inner-declarations":["error"],"no-invalid-regexp":["error"],"no-irregular-whitespace":["error"],"no-loss-of-precision":["error"],"no-misleading-character-class":["error"],"no-mixed-spaces-and-tabs":["error"],"no-new-symbol":["error"],"no-nonoctal-decimal-escape":["error"],"no-obj-calls":["error"],"no-octal":["error"],"no-prototype-builtins":["error"],"no-redeclare":["error"],"no-regex-spaces":["error"],"no-self-assign":["error"],"no-setter-return":["error"],"no-shadow-restricted-names":["error"],"no-sparse-arrays":["error"],"no-this-before-super":["error"],"no-undef":["warn"],"no-unexpected-multiline":["error"],"no-unreachable":["error"],"no-unsafe-finally":["error"],"no-unsafe-negation":["error"],"no-unsafe-optional-chaining":["error"],"no-unused-labels":["error"],"no-unused-vars":["warn"],"no-useless-backreference":["error"],"no-useless-catch":["error"],"no-useless-escape":["error"],"no-with":["error"],"require-yield":["error"],"use-isnan":["error"],"valid-typeof":["error"],...n.recommended.rules},env:{es6:!0,browser:!0,greasemonkey:!0}};i.rules["userscripts/align-attributes"]=["warn",2],i.rules["userscripts/require-download-url"]=["warn"];let o=JSON.stringify(i,null,2)},51141(e,t,r){"use strict";r.d(t,{H:()=>i,p:()=>n});class n{zipObject;constructor(e){this.zipObject=e}read(e){return this.zipObject.async(e||"string")}}class i{zip;path;modifiedDate;constructor(e,t,r){this.zip=e,this.path=t,r&&r.modifiedDate&&(this.modifiedDate=r.modifiedDate)}async write(e){let t={};if(this.modifiedDate){let e=new Date(this.modifiedDate);t.date=new Date(e.getTime()-6e4*e.getTimezoneOffset())}this.zip.file(this.path,e,t)}}},83075(e,t,r){"use strict";if(r.d(t,{A:()=>i}),/^(1709|644)$/.test(r.j))var n=r(51141);class i{zip;basePath;constructor(e,t){this.zip=e,this.basePath=t||""}async verify(){}async open(e){let t=e.name,r=this.zip.file(t);if(r)return new n.p(r);throw Error("File not found")}async openDir(e){return new i(this.zip,e)}async create(e,t){return new n.H(this.zip,e,t)}async createDir(e,t){}async delete(e){this.zip.remove(e)}async list(){let e=[];for(let[t,r]of Object.entries(this.zip.files)){let n=r.date,i=new Date(n.getTime()+6e4*n.getTimezoneOffset()).getTime();e.push({name:t,path:t,size:0,digest:"",createtime:i,updatetime:i})}return e}async getDirUrl(){throw Error("Method not implemented.")}}},86147(e,t,r){"use strict";r.d(t,{Kj:()=>a,Ng:()=>s,_z:()=>o});var n=r(65217),i=r(30986);async function o(e,t,r){let o=await e.sendMessage({action:t,data:r}),s=n.A.getInstance().logger().with({action:t,data:r,response:o});if(s.trace("sendMessage"),o?.code)throw console.error(o),o.message;try{return o.data}catch(e){s.trace("Invalid response data",i.A.E(e));return}}function s(e,t,r){return e.connect({action:t,data:r})}class a{msgSender;prefix;constructor(e,t){this.msgSender=e,this.prefix=t,this.prefix&&!this.prefix.endsWith("/")?this.prefix+="/":this.prefix=""}do(e,t){return o(this.msgSender,`${this.prefix}${e}`,t)}async doThrow(e,t){let r=await o(this.msgSender,`${this.prefix}${e}`,t);if(!r)throw Error(`doThrow: ${this.prefix}${e}`);return r}}},37321(e,t,r){"use strict";r.d(t,{S:()=>o});var n=r(392);class i{get(e){return new Promise(t=>{chrome.storage.session.get(e,r=>{let n=chrome.runtime.lastError;n&&console.error("chrome.runtime.lastError in chrome.storage.session.get:",n),t(r[e])})})}set(e,t){return new Promise(r=>{chrome.storage.session.set({[e]:t},()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.session.set:",e),r()})})}batchSet(e){return new Promise(t=>{chrome.storage.session.set(e,()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.session.set:",e),t()})})}has(e){return new Promise(t=>{chrome.storage.session.get(e,r=>{let n=chrome.runtime.lastError;n&&console.error("chrome.runtime.lastError in chrome.storage.session.get:",n),t(void 0!==r[e])})})}del(e){return new Promise(t=>{chrome.storage.session.remove(e,()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.session.remove:",e),t()})})}dels(e){return new Promise(t=>{chrome.storage.session.remove(e,()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.session.remove:",e),t()})})}clear(){return new Promise(e=>{chrome.storage.session.clear(()=>{let t=chrome.runtime.lastError;t&&console.error("chrome.runtime.lastError in chrome.storage.session.clear:",t),e()})})}list(){return new Promise(e=>{chrome.storage.session.get(null,t=>{let r=chrome.runtime.lastError;r&&console.error("chrome.runtime.lastError in chrome.storage.session.get:",r),e(Object.keys(t))})})}}let o=new class extends i{async getOrSet(e,t){let r=await this.get(e);return r||(r=await t(),this.set(e,r)),r}tx(e,t){return(0,n.e)(e,()=>{let r,n={action:0},i=e=>{n.action=1,n.newVal=e},o=()=>{n.action=2,n.newVal=void 0};return this.get(e).then(e=>t(e,{set:i,del:o})).then(t=>(r=t,1===n.action)?this.set(e,n.newVal):2===n.action?this.del(e):void 0).then(()=>r)})}incr(e,t){return this.tx(e,(e,r)=>(e=(e||0)+t,r.set(e),e))}}},45597(e,t,r){"use strict";r.d(t,{U_:()=>i,kk:()=>n});let n="importFile:",i="scriptInfo:"},23512(e,t,r){"use strict";if(r.d(t,{VH:()=>s,Xb:()=>a,eg:()=>i,qv:()=>o}),3295!=r.j)var n=r(8330);let i=3295!=r.j?n.rE:null,o="https://docs.scriptcat.org",s="https://ext.scriptcat.org/",a=644==r.j?s+"api/v1/":null},65217(e,t,r){"use strict";r.d(t,{A:()=>i});var n=r(30986);class i{static instance;static getInstance(){return i.instance}static logger(...e){return i.getInstance().logger(...e)}writer;level="info";consoleLevel="warn";labels;constructor(e){this.writer=e.writer,this.level=e.level||this.level,this.labels=e.labels||{},void 0!==e.consoleLevel&&(this.consoleLevel=e.consoleLevel),i.instance||(i.instance=this)}logger(...e){return new n.A(this,this.labels,...e)}}},30986(e,t,r){"use strict";r.d(t,{A:()=>o});var n=r(29106);let i={none:0,trace:10,debug:100,info:1e3,warn:1e4,error:1e5};class o{core;label;constructor(e,...t){this.core=e,this.label=t}log(e,t,...r){let o,s=function(...e){let t={};return e.forEach(e=>{e.forEach(e=>{Object.keys(e).forEach(r=>{t[r]=e[r]})})}),t}(this.label,r);i[e]>=i[this.core.level]&&this.core.writer.write(e,t,s);try{o=JSON.stringify(s)}catch(e){o=s,console.error("Logger label JSON stringify error:",e)}if("none"!==this.core.consoleLevel&&i[e]>=i[this.core.consoleLevel]){"object"==typeof t&&(t=JSON.stringify(t));let r=`${(0,n.U)(new Date,"YYYY-MM-DD HH:mm:ss")} [${e}] ${t}`;switch(e){case"error":console.error(r,o);break;case"warn":console.warn(r,o);break;default:console.info(r,o)}}}with(...e){return new o(this.core,...this.label,...e)}trace(e,...t){this.log("trace",e,...t)}debug(e,...t){this.log("debug",e,...t)}info(e,...t){this.log("info",e,...t)}warn(e,...t){this.log("warn",e,...t)}error(e,...t){this.log("error",e,...t)}static E(e){return"string"==typeof e?{error:e}:e instanceof Error?(console.error(e),{error:e.message}):"object"==typeof e?e:{}}}},77705(e,t,r){"use strict";r.d(t,{A:()=>n});class n{msgSender;action;constructor(e,t="logger"){this.msgSender=e,this.action=t}write(e,t,r){this.msgSender.sendMessage({action:this.action,data:{id:0,level:e,message:t,label:r,createtime:Date.now()}})}}},70258(e,t,r){"use strict";let n,i;function o(){return i?Promise.resolve(i):(n||(n=new Promise(e=>{chrome.storage.local.get(t=>{let r=chrome.runtime.lastError;r&&console.error("chrome.runtime.lastError in chrome.storage.local.get:",r),n=void 0,e(i=t||{})})})),n)}function s(e,t){return"string"==typeof e?Promise.all([o().then(r=>{r[e]=t}),new Promise(r=>{chrome.storage.local.set({[e]:t},()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.local.set:",e),r()})})]).then(()=>t):Promise.all([o().then(t=>{Object.assign(t,e)}),new Promise(t=>{chrome.storage.local.set(e,()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.local.set:",e),t()})})]).then(()=>void 0)}function a(e,t){return new Promise(r=>{chrome.storage.local.set({[e]:t},()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.local.set:",e),r(t)})})}function l(e){return new Promise(t=>{chrome.storage.local.get(e,r=>{let n=chrome.runtime.lastError;n&&console.error("chrome.runtime.lastError in chrome.storage.local.get:",n),t(r[e])})})}function c(e){return new Promise(t=>{chrome.storage.local.remove(e,()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.local.remove:",e),t()})})}function d(e){return new Promise(t=>{chrome.storage.local.remove(e,()=>{let e=chrome.runtime.lastError;e&&console.error("chrome.runtime.lastError in chrome.storage.local.remove:",e),t()})}).catch(async()=>{for(let t of e)await c(t)})}r.d(t,{lc:()=>u});class u{prefix;useCache=!1;constructor(e){this.prefix=e,e.endsWith(":")||(this.prefix+=":")}enableCache(){this.useCache=!0}joinKey(e){return this.prefix+e}async _save(e,t){return(e=this.joinKey(e),this.useCache)?s(e,t):a(e,t)}get(e){if(e=this.joinKey(e),this.useCache){var t;return t=e,o().then(e=>e[t]?Object.assign({},e[t]):e[t])}return l(e)}gets(e){return(e=e.map(e=>this.joinKey(e)),this.useCache)?o().then(t=>e.map(e=>t[e]?Object.assign({},t[e]):t[e])):new Promise(t=>{chrome.storage.local.get(e,r=>{let n=chrome.runtime.lastError;n&&console.error("chrome.runtime.lastError in chrome.storage.local.get:",n),t(e.map(e=>r[e]))})})}getRecord(e){return(e=e.map(e=>this.joinKey(e)),this.useCache)?o().then(t=>{let r={};for(let n of e)t[n]?r[n]=Object.assign({},t[n]):r[n]=t[n];return r}):new Promise(t=>{chrome.storage.local.get(e,e=>{let r=chrome.runtime.lastError;r&&console.error("chrome.runtime.lastError in chrome.storage.local.get:",r),t(e)})})}filter(e,t){let r=[];for(let n in e)n.startsWith(this.prefix)&&(!t||t(n,e[n]))&&r.push(e[n]);return r}async find(e){return this.useCache?o().then(t=>this.filter(t,e).map(e=>e?Object.assign({},e):e)):new Promise(t=>{chrome.storage.local.get(r=>{let n=chrome.runtime.lastError;n&&console.error("chrome.runtime.lastError in chrome.storage.local.get:",n),t(this.filter(r,e))})})}async findOne(e){return this.find(e).then(e=>{if(e.length>0)return e[0]})}delete(e){if(e=this.joinKey(e),this.useCache){var t;return Promise.all([(t=e,o().then(e=>{delete e[t]})),c(e)]).then(()=>void 0)}return c(e)}deletes(e){return(e=e.map(e=>this.joinKey(e)),this.useCache)?o().then(t=>{for(let r of e)delete t[r];return d(e)}):d(e)}update(e,t){return(e=this.joinKey(e),this.useCache)?o().then(r=>{let n=r[e];return!!n&&(Object.assign(n,t),s(e,n))}):l(e).then(r=>!!r&&(Object.assign(r,t),a(e,r)))}updates(e,t){let r;if(Array.isArray(e))for(let n of(r={},e))r[n]=t;else r=e;return this._doUpdates(r).then(t=>Array.isArray(e)?e.map(e=>t[e]):t)}async _doUpdates(e){let t,r=Object.keys(e),n=r.map(e=>this.joinKey(e));t=this.useCache?await o():await new Promise(e=>{chrome.storage.local.get(n,t=>{let r=chrome.runtime.lastError;r&&console.error("chrome.runtime.lastError in chrome.storage.local.get:",r),e(t)})});let i={},a={};for(let o=0;o<r.length;o++){let s=r[o],l=n[o],c=t[l];c?(Object.assign(c,e[s]),a[l]=c,i[s]=c):i[s]=!1}return Object.keys(a).length>0&&(this.useCache?await s(a):await new Promise(e=>{chrome.storage.local.set(a,()=>{let t=chrome.runtime.lastError;t&&console.error("chrome.runtime.lastError in chrome.storage.local.set:",t),e()})})),i}all(){return this.find()}}},7068(e,t,r){"use strict";r.d(t,{$Q:()=>i,Ey:()=>l,Fp:()=>o,OY:()=>s,Pk:()=>d,fn:()=>a,g0:()=>h,h8:()=>p,jo:()=>c,oU:()=>u});var n=r(70258);let i=1,o=2,s=3,a=1,l=2,c="running",d="complete",u="error";class h extends n.lc{scriptCodeDAO=new p;constructor(){super("script")}enableCache(){super.enableCache(),this.scriptCodeDAO.enableCache()}save(e){return super._save(e.uuid,e)}findByUUID(e){return this.get(e)}async getAndCode(e){let[t,r]=await Promise.all([this.get(e),this.scriptCodeDAO.get(e)]);if(t&&r)return Object.assign(t,r)}findByName(e){return this.findOne((t,r)=>r.name===e)}findByNameAndNamespace(e,t){return this.findOne((r,n)=>n.name===e&&(!t||n.namespace===t))}findByUUIDAndSubscribeUrl(e,t){return this.findOne((r,n)=>n.uuid===e&&n.subscribeUrl===t)}findByOriginAndSubscribeUrl(e,t){return this.findOne((r,n)=>n.origin===e&&n.subscribeUrl===t)}async searchExistingScript(e,t=!0){let r=e=>{if(e.startsWith("https://scriptcat.org/scripts/code/")&&e.endsWith(".js")){let t=e.indexOf("/",35),r=e.indexOf("/",t+1);if(t>0&&r<0){let r=e.indexOf(".",t+1);return e.substring(0,t+1)+"*"+e.substring(r)}}if(e.startsWith("https://update.greasyfork.org/scripts/")&&e.endsWith(".js")){let t=e.indexOf("/",38),r=e.indexOf("/",t+1);if(t>0&&r<0){let r=e.indexOf(".",t+1);return e.substring(0,t+1)+"*"+e.substring(r)}}if(e.startsWith("https://openuserjs.org/install/")&&e.endsWith(".js")){let t=e.indexOf("/",31),r=e.indexOf("/",t+1);if(t>0&&r<0){let r=e.indexOf(".",t+1);return e.substring(0,t+1)+"*"+e.substring(r)}}return e},n=(e,t)=>e&&t&&Array.isArray(e)&&Array.isArray(t)?e.length===t.length&&(e.length<2?e[0]===t[0]:new Set([...e,...t]).size===e.length):e===t,i=(e,t)=>!!n(e.metadata.author,t.metadata.author)&&!!n(e.metadata.copyright,t.metadata.copyright)&&!!n(e.metadata.license,t.metadata.license)&&!!n(e.metadata.grant,t.metadata.grant)&&!!n(e.metadata.connect,t.metadata.connect)&&!!n(e.metadata.match,t.metadata.match)&&!!n(e.metadata.include,t.metadata.include)&&!0,{metadata:o,origin:s}=e;if(!s||o?.updateurl?.[0]||o?.downloadurl?.[0])if(!(s&&(o?.updateurl?.[0]||o?.downloadurl?.[0])))return[];else{let n=r(s),a=r(o?.updateurl?.[0]||""),l=r(o?.downloadurl?.[0]||"");return this.find((o,s)=>{if(!s.origin||n!==r(s.origin))return!1;let c=r(s.metadata?.updateurl?.[0]||""),d=r(s.metadata?.downloadurl?.[0]||"");return a===c&&l===d&&(!t||!!i(e,s))})}{let n=r(s);return this.find((o,s)=>!!s.origin&&n===r(s.origin)&&(!t||!!i(e,s)))}}}class p extends n.lc{constructor(){super("scriptCode")}findByUUID(e){return this.get(e)}save(e){return super._save(e.uuid,e)}}},89043(e,t,r){"use strict";r.d(t,{$D:()=>u,CP:()=>d,SL:()=>a,XW:()=>g,bx:()=>o,ic:()=>c,iw:()=>p,rp:()=>l,vz:()=>s,y$:()=>h});var n=r(86147),i=r(96349);class o extends n.Kj{constructor(e){super(e,"serviceWorker")}preparationOffscreen(){return this.do("preparationOffscreen")}}class s extends n.Kj{constructor(e){super(e,"serviceWorker/script")}getAllScripts(){return this.doThrow("getAllScripts")}getInstallInfo(e){return this.do("getInstallInfo",e)}install(e){return e.upsertBy||(e.upsertBy="user"),this.doThrow("install",{...e})}deletes(e){return this.do("deletes",e)}enable(e,t){return this.do("enable",{uuid:e,enable:t})}enables(e,t){return this.do("enables",{uuids:e,enable:t})}info(e){return this.doThrow("fetchInfo",e)}getFilterResult(e){return this.do("getFilterResult",e)}getScriptRunResourceByUUID(e){return this.doThrow("getScriptRunResourceByUUID",e)}excludeUrl(e,t,r){return this.do("excludeUrl",{uuid:e,excludePattern:t,remove:r})}resetMatch(e,t){return this.do("resetMatch",{uuid:e,match:t})}resetExclude(e,t){return this.do("resetExclude",{uuid:e,exclude:t})}requestCheckUpdate(e){return this.do("requestCheckUpdate",e)}sortScript(e){return this.do("sortScript",e)}pinToTop(e){return this.do("pinToTop",e)}importByUrl(e){return this.doThrow("importByUrl",e)}installByCode(e,t,r="user"){return this.do("installByCode",{uuid:e,code:t,upsertBy:r})}setCheckUpdateUrl(e,t,r){return this.do("setCheckUpdateUrl",{uuid:e,checkUpdate:t,checkUpdateUrl:r})}updateMetadata(e,t,r){return this.do("updateMetadata",{uuid:e,key:t,value:r})}async getBatchUpdateRecordLite(e){return this.do("getBatchUpdateRecordLite",e)}async fetchCheckUpdateStatus(){return this.do("fetchCheckUpdateStatus")}async sendUpdatePageOpened(){return this.do("sendUpdatePageOpened")}async batchUpdateListAction(e){return this.do("batchUpdateListAction",e)}async openUpdatePageByUUID(e){return this.do("openUpdatePageByUUID",e)}async openBatchUpdatePage(e){return this.do("openBatchUpdatePage",e)}async checkScriptUpdate(e){return this.do("checkScriptUpdate",e)}}class a extends n.Kj{constructor(e){super(e,"serviceWorker/resource")}getScriptResources(e){return this.doThrow("getScriptResources",e)}deleteResource(e){return this.do("deleteResource",e)}}class l extends n.Kj{constructor(e){super(e,"serviceWorker/value")}getScriptValue(e){return this.doThrow("getScriptValue",e)}setScriptValue({uuid:e,key:t,value:r,ts:n}){let o=[[t,(0,i._8)(r)]];return this.do("setScriptValues",{uuid:e,keyValuePairs:o,ts:n})}setScriptValues(e){return this.do("setScriptValues",e)}}class c extends n.Kj{constructor(e){super(e,"serviceWorker/runtime")}runScript(e){return this.do("runScript",e)}stopScript(e){return this.do("stopScript",e)}pageLoad(){return this.doThrow("pageLoad")}scriptLoad(e,t){return this.do("scriptLoad",{flag:e,uuid:t})}}class d extends n.Kj{constructor(e){super(e,"serviceWorker/popup")}getPopupData(e){return this.doThrow("getPopupData",e)}menuClick(e,t,r){return this.do("menuClick",{uuid:e,menus:t,inputValue:r})}}class u extends n.Kj{constructor(e){super(e,"serviceWorker/runtime/permission")}confirm(e,t){return this.do("confirm",{uuid:e,userConfirm:t})}getPermissionInfo(e){return this.doThrow("getInfo",e)}deletePermission(e,t,r){return this.do("deletePermission",{uuid:e,permission:t,permissionValue:r})}getScriptPermissions(e){return this.doThrow("getScriptPermissions",e)}addPermission(e){return this.do("addPermission",e)}updatePermission(e){return this.do("updatePermission",e)}resetPermission(e){return this.do("resetPermission",e)}}class h extends n.Kj{constructor(e){super(e,"serviceWorker/synchronize")}export(e){return this.do("export",e)}backupToCloud(e,t){return this.do("backupToCloud",{type:e,params:t})}importResources(e,t,r,n){return this.do("importResources",{uuid:e,requires:t,resources:r,requiresCss:n})}}class p extends n.Kj{constructor(e){super(e,"serviceWorker/subscribe")}install(e){return this.do("install",{subscribe:e})}delete(e){return this.do("delete",{url:e})}checkUpdate(e){return this.do("checkUpdate",{url:e})}enable(e,t){return this.do("enable",{url:e,enable:t})}}class g extends n.Kj{constructor(e){super(e,"serviceWorker/system")}connectVSCode(e){return this.do("connectVSCode",e)}}},27503(e,t,r){"use strict";r.d(t,{hj:()=>n,lM:()=>o,sE:()=>i});let n="https://royext.sohailsyed.com/verify.php",i="https://royext.sohailsyed.com/scripts_api.php",o=644==r.j?18e5:null},87330(e,t,r){"use strict";if(r.d(t,{Bo:()=>c,H$:()=>i,IQ:()=>s,OL:()=>l,S0:()=>u,Wz:()=>p,Xh:()=>h,cg:()=>d,rX:()=>o,s3:()=>a}),!/^(3295|5357)$/.test(r.j))var n=r(27503);function i(){return new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_fingerprint"],t=>{if(t.vip_fingerprint)e(t.vip_fingerprint);else{let t=new Uint8Array(16);if("u">typeof crypto&&crypto.getRandomValues)crypto.getRandomValues(t);else for(let e=0;e<16;e++)t[e]=Math.floor(256*Math.random());let r="royext-"+Array.from(t,e=>e.toString(16).padStart(2,"0")).join("");chrome.storage.local.set({vip_fingerprint:r},()=>{e(r)})}}):e("local-dev-fingerprint")})}async function o(e,t,r="VIP Member",i=0,s="",a=""){try{let o=await fetch(n.hj,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key:e.trim(),fingerprint:t,name:r,age:i,email:s,phone:a})});if(!o.ok)throw Error(`HTTP error ${o.status}`);let l=await o.json();if(l&&l.valid)return{valid:!0,expires:l.expires,keyId:l.key_id||"online",plan_type:l.plan_type||void 0,activated_at:l.activated_at||void 0};return{valid:!1,expires:0,keyId:"",error:l.error||"Key validation failed."}}catch(e){return console.error("Online validation request failed:",e),{valid:!1,expires:0,keyId:"",error:"Could not connect to verification server. Please check your internet connection."}}}async function s(e){try{let t=await fetch(n.hj,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"pre_verify",key:e.trim()})});if(!t.ok)throw Error(`HTTP error ${t.status}`);let r=await t.json();if(r&&r.valid)return{valid:!0,expires:r.expires,keyId:"pre_verify"};return{valid:!1,expires:0,keyId:"",error:r.error||"Key validation failed."}}catch(e){return console.error("Pre-verification online request failed:",e),{valid:!1,expires:0,keyId:"",error:"Could not connect to verification server. Please check your internet connection."}}}function a(){return new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_active","vip_name","vip_age","vip_email","vip_phone","vip_expires","vip_key","vip_plan_type","vip_activated_at"],t=>{if(!t.vip_active||!t.vip_key)return void e({active:!1,name:"",age:0,expires:0});let r=t.vip_expires||0;if(-1!==r&&Date.now()>r)chrome.storage.local.set({vip_active:!1}),e({active:!1,name:t.vip_name||"",age:t.vip_age||0,expires:r});else{let n=t.vip_activated_at;n||(n=Math.floor(Date.now()/1e3),chrome.storage.local.set({vip_activated_at:n})),e({active:!0,name:t.vip_name||"",age:t.vip_age||0,email:t.vip_email||"",phone:t.vip_phone||"",expires:r,plan_type:t.vip_plan_type||"",activated_at:n})}}):e({active:!1,name:"",age:0,expires:0})})}async function l(){let e=await new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_key","vip_fingerprint"],t=>{e({key:t.vip_key,fingerprint:t.vip_fingerprint})}):e({})}),t=e.key||"",r=e.fingerprint||"",i=e=>t&&r?e.map(e=>({...e,downloadUrl:`${e.downloadUrl}&key=${encodeURIComponent(t)}&fingerprint=${encodeURIComponent(r)}`})):e;if("u">typeof chrome&&chrome.storage&&chrome.storage.local){let e=await new Promise(e=>{chrome.storage.local.get(["vip_scripts_cache","vip_scripts_cached_at"],t=>{e({scripts:t.vip_scripts_cache,cachedAt:t.vip_scripts_cached_at})})});if(e.scripts&&e.cachedAt&&Date.now()-e.cachedAt<n.lM)return i(e.scripts)}try{let e=await fetch(n.sE,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"list",key:t,fingerprint:r})});if(!e.ok)throw Error(`HTTP error ${e.status}`);let o=await e.json();if(o.success&&Array.isArray(o.scripts)){let e=o.scripts;return"u">typeof chrome&&chrome.storage&&chrome.storage.local&&chrome.storage.local.set({vip_scripts_cache:e,vip_scripts_cached_at:Date.now()}),i(e)}throw Error(o.error||"Invalid response format from scripts API")}catch(e){if(console.warn("Failed to fetch VIP scripts from server, checking cache:",e),"u">typeof chrome&&chrome.storage&&chrome.storage.local){let e=await new Promise(e=>{chrome.storage.local.get(["vip_scripts_cache"],t=>{e({scripts:t.vip_scripts_cache})})});if(e.scripts&&e.scripts.length>0)return console.log("Returning stale cached scripts after fetch failure"),i(e.scripts)}throw Error(e.message||"Failed to connect to the scripts server.")}}async function c(){try{let e=await new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_key"],t=>{e({key:t.vip_key})}):e({})});if(!e.key)return{revoked:!1,message:""};let t=await fetch(n.hj,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"check_status",key:e.key})});if(!t.ok)return console.warn("Revocation check: server returned HTTP",t.status),{revoked:!1,message:""};let r=await t.json();if(!0===r.revoked)return"u">typeof chrome&&chrome.storage&&chrome.storage.local&&chrome.storage.local.remove(["vip_active","vip_key","vip_name","vip_age","vip_expires","vip_plan_type","vip_activated_at"]),{revoked:!0,message:r.revoke_message||"Your access has been revoked by the Admin."};return{revoked:!1,message:""}}catch(e){return console.warn("Revocation check failed (network):",e),{revoked:!1,message:""}}}async function d(e){try{let t=await new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_key","vip_fingerprint"],t=>{e({key:t.vip_key,fingerprint:t.vip_fingerprint})}):e({})});if(!t.key)throw Error("No license key found.");let r=await fetch(n.sE,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"backup_settings",key:t.key,fingerprint:t.fingerprint||"",settings_json:e})});return await r.json()}catch(e){return{success:!1,error:e.message||"Failed to connect to the backup server."}}}async function u(){try{let e=await new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_key","vip_fingerprint"],t=>{e({key:t.vip_key,fingerprint:t.vip_fingerprint})}):e({})});if(!e.key)throw Error("No license key found.");let t=await fetch(n.sE,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"restore_settings",key:e.key,fingerprint:e.fingerprint||""})});return await t.json()}catch(e){return{success:!1,error:e.message||"Failed to connect to the backup server."}}}async function h(){try{let e=await new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_key","vip_fingerprint"],t=>{e({key:t.vip_key,fingerprint:t.vip_fingerprint})}):e({})});if(!e.key)return[];let t=await fetch(n.sE,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"announcements",key:e.key,fingerprint:e.fingerprint||""})}),r=await t.json();if(r.success&&Array.isArray(r.announcements)){let e=r.announcements;return"u">typeof chrome&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(["vip_seen_announcements"],t=>{let r=t.vip_seen_announcements||[],n=[...r],i=!1;e.forEach(e=>{!r.includes(e.id)&&(n.push(e.id),i=!0,chrome.notifications&&chrome.notifications.create&&chrome.notifications.create({type:"basic",title:e.title||"RoyExt System Announcement",message:e.content||"",iconUrl:chrome.runtime.getURL("assets/logo.png")}))}),i&&chrome.storage.local.set({vip_seen_announcements:n})}),e}return[]}catch(e){return console.warn("Failed to fetch announcements:",e),[]}}async function p(e,t,r){try{let i=await new Promise(e=>{!("u"<typeof chrome)&&chrome.storage&&chrome.storage.local?chrome.storage.local.get(["vip_key","vip_fingerprint"],t=>{e({key:t.vip_key,fingerprint:t.vip_fingerprint})}):e({})});if(!i.key)throw Error("No license key found.");let o=await fetch(n.sE,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"submit_feedback",key:i.key,fingerprint:i.fingerprint||"",script_id:e,feedback_type:t,message:r})});return await o.json()}catch(e){return{success:!1,error:e.message||"Failed to submit feedback."}}}},86774(e,t,r){"use strict";if(r.d(t,{g:()=>d}),!/^(3295|5357)$/.test(r.j))var n=r(77069);if(!/^(3295|5357)$/.test(r.j))var i=r(16707);if(!/^(3295|5357)$/.test(r.j))var o=r(49331);if(!/^(3295|5357)$/.test(r.j))var s=r(62341);if(!/^(3295|5357)$/.test(r.j))var a=r(84318);if(!/^(3295|5357)$/.test(r.j))var l=r(25767);if(!/^(3295|5357)$/.test(r.j))var c=r(24918);function d(e){switch(e){case"en-US":default:return n.A;case"zh-CN":return i.A;case"zh-TW":return o.A;case"ja-JP":return s.A;case"de-DE":return a.A;case"vi-VN":return l.A;case"ru-RU":return c.A}}},55984(e,t,r){"use strict";let n;r.d(t,{Ay:()=>S,MF:()=>y,NC:()=>x,W1:()=>k,ZA:()=>j,ig:()=>_,sg:()=>v,v2:()=>b});var i=r(40403),o=r(66901),s=r(95586),a=r.n(s),l=r(61192),c=r.n(l);if(3295!=r.j)var d=r(79833);if(3295!=r.j)var u=r(77387);if(3295!=r.j)var h=r(59447);if(3295!=r.j)var p=r(94911);if(3295!=r.j)var g=r(86673);if(3295!=r.j)var m=r(62826);if(3295!=r.j)var f=r(79982);r(91077),r(32207),r(2632),r(288),r(34899),r(5277),r(9695),a().extend(c());let y="";function b(e,t){i.Ay.changeLanguage(e,t),a().locale(e.toLocaleLowerCase())}function x(e="en-US"){i.Ay.use(o.r9).init({fallbackLng:"en-US",lng:e,interpolation:{escapeValue:!1},resources:{"en-US":{title:"English",translation:d},"zh-CN":{title:"简体中文",translation:h},"zh-TW":{title:"繁体中文",translation:p},"ja-JP":{title:"日本語",translation:g},"de-DE":{title:"Deutsch",translation:m},"vi-VN":{title:"Tiếng Việt",translation:u},"ru-RU":{title:"Русский",translation:f}}}),e.startsWith("zh-")||(y="/en")}function v(e){let t=chrome.i18n.getUILanguage();x(globalThis.localStorage&&localStorage.language||t);let r=e=>{y=e.startsWith("zh-")?"":"/en",b(e)};e.getLanguage().then(e=>{n(e),r(e)}),e.addListener("language",r)}new Promise(e=>{n=e});let w=()=>`${i.Ay?.language?.toLowerCase()}`;function k(e){let t=w(),r=e.metadata[`name:${t}`];if(!r){let n=t.split("-")[0];r=e.metadata[`name:${n}`]}return r?r[0]:e.name}function j(e){let t=e.metadata,r=w(),n=t[`description:${r}`];if(!n){let e=r.split("-")[0];n=t[`description:${e}`]}return n?n[0]:t.description?.[0]||""}function _(){return chrome.i18n.getAcceptLanguages().then(e=>{for(let t=0;t<e.length;t+=1){let r=e[t];if(i.Ay.hasResourceBundle(r,"translation"))return r}let t={};for(let e of i.Ay.languages){let r=e.split("-")[0];t[r]||(t[r]=[]),t[r].push(e)}for(let r=0;r<e.length;r+=1){let n=e[r].split("-")[0];if(t[n]&&t[n].length>0)return t[n][0]}return""})}let S=/^(3295|5357)$/.test(r.j)?null:i.Ay},64838(e,t,r){"use strict";r.d(t,{A:()=>l});var n=r(64213),i=r(82905),o=r(95217);if(/^6(44|905)$/.test(r.j))var s=r(70731);if(/^6(44|905)$/.test(r.j))var a=r(89444);r(59582).CB.setEditorTheme=e=>i.EN.setTheme(e);let l=/^6(44|905)$/.test(r.j)?o.forwardRef(({id:e,className:t,code:r,diffCode:l,editable:c},d)=>{let[u,h]=(0,o.useState)(),[p,g]=(0,o.useState)(!1),[m,f]=(0,o.useState)(""),y=(0,o.useRef)(null);return(0,o.useImperativeHandle)(d,()=>({editor:u})),(0,o.useEffect)(()=>{Promise.all([s.EO.getEslintConfig(),s.EO.getEnableEslint()]).then(([e,t])=>{f(e),g(t)})},[]),(0,o.useEffect)(()=>{let t,n,o;if(void 0===l||void 0===r||!y.current)return()=>{};let s=document.getElementById(e),a={folding:!0,foldingStrategy:"indentation",automaticLayout:!0,scrollbar:{alwaysConsumeMouseWheel:!1},overviewRulerBorder:!1,scrollBeyondLastLine:!1,glyphMargin:!0,unicodeHighlight:{ambiguousCharacters:!1},acceptSuggestionOnCommitCharacter:!0,acceptSuggestionOnEnter:"on",quickSuggestionsDelay:10,suggestOnTriggerCharacters:!0,tabCompletion:"off",suggest:{localityBonus:!0,preview:!0},suggestSelection:"first",wordBasedSuggestions:"off",parameterHints:{enabled:!0},quickSuggestions:{other:!0,comments:!0,strings:!0},fastScrollSensitivity:10,smoothScrolling:!0,inlineSuggest:{enabled:!0},guides:{indentation:!0},renderLineHighlightOnlyWhenFocus:!0,snippetSuggestions:"top",cursorBlinking:"phase",cursorSmoothCaretAnimation:"off",autoIndent:"advanced",wrappingIndent:"indent",wordSegmenterLocales:["ja","zh-CN","zh-Hant-TW"],renderLineHighlight:"gutter",renderWhitespace:"selection",renderControlCharacters:!0,dragAndDrop:!1,emptySelectionClipboard:!1,copyWithSyntaxHighlighting:!1,bracketPairColorization:{enabled:!0},mouseWheelZoom:!0,links:!0,accessibilitySupport:"off",largeFileOptimizations:!0,colorDecorators:!0};return l?(t=i.EN.createDiffEditor(s,{hideUnchangedRegions:{enabled:!0},enableSplitViewResizing:!1,renderSideBySide:!1,readOnly:!0,diffWordWrap:"off",...a}),n=i.EN.createModel(l,"javascript"),o=i.EN.createModel(r,"javascript"),t.setModel({original:n,modified:o})):((t=i.EN.create(s,{language:"javascript",theme:"dark"===document.body.getAttribute("arco-theme")?"vs-dark":"vs",readOnly:!c,...a})).setValue(r),h(t)),()=>{t?.dispose(),n?.dispose(),o?.dispose()}},[y,r,l,c,e]),(0,o.useEffect)(()=>{let t;if(!p||!u)return()=>{};let r=u.getModel();if(!r)return()=>{};let n=()=>{t&&clearTimeout(t),t=setTimeout(()=>{t=null,a.v.sendLinterMessage({code:r.getValue(),id:e,config:JSON.parse(m)})},500)};n(),r.onDidChangeContent(()=>{n()});let o=t=>{var n;let o,a;if(e!==t.id)return;i.EN.setModelMarkers(r,"ESLint",t.markers);let l=new Map;t.markers.forEach(e=>{e.fix&&l.set(`${e.code.value}|${e.startLineNumber}|${e.endLineNumber}|${e.startColumn}|${e.endColumn}`,e.fix)}),s.Eb.set("eslint-fix",l),n=t.markers.map(({startLineNumber:e,endLineNumber:t,severity:r})=>({startLineNumber:e,endLineNumber:t,severity:r})),o={4:"icon-warn",8:"icon-error"},a=r.getAllDecorations().filter(e=>e.options.glyphMarginClassName&&Object.values(o).includes(e.options.glyphMarginClassName)),u.removeDecorations(a.map(e=>e.id)),u.createDecorationsCollection(n.map(({startLineNumber:e,endLineNumber:t,severity:r})=>({range:new i.Q6(e,1,t,1),options:{isWholeLine:!0,glyphMarginClassName:o[r]}})))};return a.v.hook.addListener("message",o),()=>{a.v.hook.removeListener("message",o)}},[e,u,p,m]),(0,n.jsx)("div",{id:e,className:t,ref:y})}):null},68151(e,t,r){"use strict";r.d(t,{A:()=>o});var n=r(64213),i=r(95217);class o extends i.Component{constructor(e){super(e),this.state={hasError:!1,error:null,errorInfo:null}}static getDerivedStateFromError(e){return{hasError:!0,error:e}}componentDidCatch(e,t){console.error("ErrorBoundary caught an error",e,t),this.setState({errorInfo:t})}render(){return this.state.hasError?(0,n.jsxs)("div",{style:{padding:24,background:"#120f1c",color:"#fff",fontFamily:"monospace",overflow:"auto",height:"100vh",boxSizing:"border-box"},children:[(0,n.jsx)("h2",{style:{color:"#ff4d4f"},children:"\uD83D\uDC51 RoyExt Runtime Exception caught:"}),(0,n.jsx)("p",{style:{color:"#ff7875",fontWeight:"bold",fontSize:16},children:this.state.error?.toString()}),(0,n.jsx)("h3",{children:"Stack Trace:"}),(0,n.jsx)("pre",{style:{background:"#1f1b2e",padding:16,borderRadius:8,overflowX:"auto"},children:this.state.error?.stack}),this.state.errorInfo&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("h3",{children:"Component Tree Stack:"}),(0,n.jsx)("pre",{style:{background:"#1f1b2e",padding:16,borderRadius:8,overflowX:"auto"},children:this.state.errorInfo.componentStack})]})]}):this.props.children}}},11879(e,t,r){"use strict";r.d(t,{A:()=>b});var n=r(64213),i=r(95217),o=r(98855);if(!/^(3295|5357)$/.test(r.j))var s=r(38194);if(!/^(3295|5357)$/.test(r.j))var a=r(50998);if(!/^(3295|5357)$/.test(r.j))var l=r(87248);if(!/^(3295|5357)$/.test(r.j))var c=r(37576);if(!/^(3295|5357)$/.test(r.j))var d=r(9200);if(!/^(3295|5357)$/.test(r.j))var u=r(93681);if(!/^(3295|5357)$/.test(r.j))var h=r(8700);if(!/^(3295|5357)$/.test(r.j))var p=r(22956);if(!/^(3295|5357)$/.test(r.j))var g=r(87330);let{Title:m,Text:f,Paragraph:y}=o.A;function b({children:e}){let t="u">typeof window&&window.location.pathname.includes("popup.html"),[r,o]=(0,i.useState)(!0),[x,v]=(0,i.useState)(!0),[w,k]=(0,i.useState)(!1),[j,_]=(0,i.useState)(""),[S,C]=(0,i.useState)(1),[A,E]=(0,i.useState)(""),[T,L]=(0,i.useState)(0),[M,R]=(0,i.useState)(""),[U,P]=(0,i.useState)(""),[D,$]=(0,i.useState)(""),[O,N]=(0,i.useState)(""),[I,z]=(0,i.useState)(!1),[B,G]=(0,i.useState)(!1),F=(0,i.useRef)(null);(0,i.useEffect)(()=>(console.log("[VIPLock] Component mounted. Initiating VIP check..."),H(),()=>{F.current&&clearInterval(F.current)}),[]);let V=()=>{F.current||(console.log("[VIPLock] Starting periodic revocation polling (every 2 min)"),F.current=setInterval(async()=>{try{console.log("[VIPLock] Periodic revocation check...");let e=await (0,g.Bo)();e.revoked&&(console.log("[VIPLock] REVOKED detected during periodic check!"),"u">typeof chrome&&chrome.storage&&chrome.storage.local&&chrome.storage.local.remove(["vip_active","vip_key","vip_name","vip_age","vip_expires","vip_plan_type","vip_activated_at"]),k(!0),_(e.message),v(!0),F.current&&(clearInterval(F.current),F.current=null))}catch(e){console.warn("[VIPLock] Periodic revocation check failed:",e)}},12e4))},H=async()=>{try{let e=await (0,g.s3)();console.log("[VIPLock] checkVIPStatus result:",e),e.active?(v(!1),o(!1),console.log("[VIPLock] Local check passed. UI unlocked. Checking server for revocation in background..."),(0,g.Bo)().then(e=>{e.revoked?(console.log("[VIPLock] KEY REVOKED BY ADMIN in background check!"),"u">typeof chrome&&chrome.storage&&chrome.storage.local&&chrome.storage.local.remove(["vip_active","vip_key","vip_name","vip_age","vip_expires","vip_plan_type","vip_activated_at"]),k(!0),_(e.message),v(!0)):V()}).catch(e=>{console.warn("[VIPLock] Background revocation check failed, keeping unlocked:",e),V()})):(console.log("[VIPLock] Activation check failed or no license key found. Locking content."),v(!0),o(!1))}catch(e){console.error("[VIPLock] Error checking status:",e),v(!0),o(!1)}},W=async()=>{let e=A.trim();if(!e)return void s.A.warning("Please enter your license key");G(!0);try{let t=await (0,g.IQ)(e);if(!t.valid)return void s.A.error(t.error||"Invalid or Expired License Key. Please purchase a valid key.");L(t.expires),s.A.success("License key verified successfully!"),C(2)}catch(e){s.A.error("Verification failed: "+(e.message||e))}finally{G(!1)}},K=async()=>{if(!M.trim())return void s.A.warning("Please enter your name");if(!U.trim()||isNaN(Number(U))||0>=Number(U))return void s.A.warning("Please enter a valid age");if(!D.trim()||!D.includes("@"))return void s.A.warning("Please enter a valid Gmail/Email address");if(!O.trim()||O.length<8)return void s.A.warning("Please enter a valid Phone Number");if(!I)return void s.A.warning("You must accept the Legal Notice to proceed");G(!0);try{let e=await (0,g.H$)(),t=await (0,g.rX)(A.trim(),e,M.trim(),Number(U),D.trim(),O.trim());if(!t.valid)return void s.A.error(t.error||"Activation failed on the server.");chrome.storage.local.set({vip_active:!0,vip_name:M.trim(),vip_age:Number(U),vip_email:D.trim(),vip_phone:O.trim(),vip_expires:t.expires,vip_key:A.trim(),vip_plan_type:t.plan_type||"",vip_activated_at:t.activated_at||Math.floor(Date.now()/1e3)},()=>{C(3)})}catch(e){s.A.error("Activation failed: "+(e.message||e))}finally{G(!1)}};return r?(console.log("[VIPLock] Rendering Loading screen."),(0,n.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"100vh",width:"100%",background:"#09070f",color:"#fff",boxSizing:"border-box",fontFamily:"'Outfit', sans-serif"},children:"Loading RoyExt Activation Vault..."})):x?w?(console.log("[VIPLock] Rendering REVOKED screen."),(0,n.jsxs)("div",{style:{minHeight:t?"100%":"100vh",height:t?"100%":void 0,width:"100%",background:"linear-gradient(135deg, #0a0208 0%, #1a0a0a 50%, #0a0208 100%)",display:"flex",alignItems:"center",justifyContent:"center",padding:t?10:20,boxSizing:"border-box",fontFamily:"'Outfit', sans-serif"},children:[(0,n.jsx)(a.A,{style:{width:"100%",maxWidth:480,borderRadius:t?12:16,border:"2px solid #dc2626",background:"linear-gradient(135deg, #1a0a0a 0%, #200d0d 100%)",boxShadow:"0 10px 60px rgba(220, 38, 38, 0.3), 0 0 100px rgba(220, 38, 38, 0.1)"},bodyStyle:{padding:t?16:40},children:(0,n.jsxs)("div",{style:{textAlign:"center"},children:[(0,n.jsx)("div",{style:{background:"rgba(220, 38, 38, 0.15)",borderRadius:"50%",width:t?44:80,height:t?44:80,display:"flex",alignItems:"center",justifyContent:"center",margin:t?"0 auto 10px auto":"0 auto 20px auto",boxShadow:"0 0 30px rgba(220, 38, 38, 0.3)",animation:"pulse 2s infinite"},children:(0,n.jsx)("span",{style:{fontSize:t?20:40},children:"\uD83D\uDEAB"})}),(0,n.jsx)(m,{heading:t?5:3,style:{margin:0,fontWeight:800,color:"#ef4444",marginBottom:8},children:"Access Revoked"}),(0,n.jsx)(y,{style:{fontSize:t?12:15,color:"#fca5a5",lineHeight:1.5,marginBottom:4},children:j||"Your access has been revoked by the Admin."}),(0,n.jsx)(y,{style:{fontSize:t?10:13,color:"rgba(255,255,255,0.4)",lineHeight:1.4,marginTop:0},children:"Your RoyExt license has been deactivated. You can no longer use this extension until your access is restored."}),(0,n.jsxs)("div",{style:{marginTop:t?12:28,padding:t?"10px 12px":"16px 20px",background:"rgba(220, 38, 38, 0.08)",borderRadius:12,border:"1px solid rgba(220, 38, 38, 0.2)"},children:[(0,n.jsx)(f,{style:{fontSize:t?10:12,color:"rgba(255,255,255,0.5)",display:"block",marginBottom:6},children:"Think this is a mistake? Contact the Admin:"}),(0,n.jsxs)("a",{href:"https://wa.link/pb3pwk",target:"_blank",rel:"noreferrer",style:{display:"inline-flex",alignItems:"center",gap:10,padding:t?"6px 14px":"12px 28px",background:"linear-gradient(135deg, #25d366 0%, #128c7e 100%)",color:"#fff",borderRadius:10,fontWeight:700,fontSize:t?11:14,textDecoration:"none",boxShadow:"0 4px 20px rgba(37, 211, 102, 0.3)",transition:"transform 0.2s ease, box-shadow 0.2s ease"},onMouseOver:e=>{e.currentTarget.style.transform="translateY(-2px)",e.currentTarget.style.boxShadow="0 6px 28px rgba(37, 211, 102, 0.4)"},onMouseOut:e=>{e.currentTarget.style.transform="translateY(0)",e.currentTarget.style.boxShadow="0 4px 20px rgba(37, 211, 102, 0.3)"},children:[(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"currentColor",children:(0,n.jsx)("path",{d:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"})}),"Contact Admin"]})]})]})}),(0,n.jsx)("style",{children:`
          @keyframes pulse {
            0%, 100% { transform: scale(1); box-shadow: 0 0 30px rgba(220, 38, 38, 0.3); }
            50% { transform: scale(1.05); box-shadow: 0 0 50px rgba(220, 38, 38, 0.5); }
          }
        `})]})):(console.log("[VIPLock] Rendering Activation Required Lock UI. Step:",S),(0,n.jsx)("div",{style:{minHeight:t?"100%":"100vh",height:t?"100%":void 0,width:"100%",background:"linear-gradient(135deg, #09070f 0%, #120f1c 100%)",display:"flex",alignItems:"center",justifyContent:"center",padding:t?10:20,boxSizing:"border-box",fontFamily:"'Outfit', sans-serif"},children:(0,n.jsxs)(a.A,{style:{width:"100%",maxWidth:480,borderRadius:t?12:16,border:"2px solid #7c3aed",background:"#120f1c",boxShadow:"0 10px 40px rgba(0, 0, 0, 0.4)"},bodyStyle:{padding:t?16:32},children:[(0,n.jsxs)("div",{style:{textAlign:"center",marginBottom:t?12:28},children:[(0,n.jsx)("div",{style:{background:"rgba(124, 58, 237, 0.15)",borderRadius:"50%",width:t?44:60,height:t?44:60,display:"flex",alignItems:"center",justifyContent:"center",margin:t?"0 auto 10px auto":"0 auto 16px auto",boxShadow:"0 0 15px rgba(124, 58, 237, 0.2)"},children:1===S?(0,n.jsx)(h.A,{style:{fontSize:t?20:28,color:"#a78bfa"}}):2===S?(0,n.jsx)(p.A,{style:{fontSize:t?20:28,color:"#f7ba1e"}}):(0,n.jsx)("span",{style:{fontSize:t?24:32},children:"\uD83D\uDC51"})}),(0,n.jsx)(m,{heading:t?5:3,style:{margin:0,fontWeight:700,color:"#fff"},children:1===S?"RoyExt Activation Required":2===S?"VIP Member Registration":"Welcome to VIP Royal!"}),(0,n.jsx)(y,{style:{fontSize:t?11:13,color:"var(--color-text-3)",marginTop:6,marginBottom:0},children:1===S?"Please enter your paid license key code to unlock this extension.":2===S?"Complete your VIP details to initialize your membership profile.":"Thank you for joining VIP Royal Membership."})]}),1===S?(0,n.jsxs)(l.A,{direction:"vertical",size:t?"small":"medium",style:{width:"100%"},children:[(0,n.jsx)(c.A.Password,{value:A,onChange:e=>E(e),placeholder:"Paste License Key here...",style:{height:t?38:44,borderRadius:8,background:"var(--color-bg-1)",border:"1px solid var(--color-border-2)"}}),(0,n.jsx)(d.A,{type:"primary",size:"large",style:{width:"100%",height:t?38:44,borderRadius:8,background:"linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%)",border:"none",fontWeight:600,boxShadow:"0 4px 10px rgba(124, 58, 237, 0.2)"},onClick:W,children:"Verify License Key"}),(0,n.jsx)("div",{style:{textAlign:"center",marginTop:t?8:12},children:(0,n.jsxs)(f,{style:{fontSize:t?11:12,color:"var(--color-text-3)"},children:["Don't have a VIP License?"," ",(0,n.jsx)("a",{href:"https://wa.link/pb3pwk",target:"_blank",rel:"noreferrer",style:{color:"#a78bfa",fontWeight:600},children:"Buy Premium on Whatsapp"})]})})]}):2===S?(0,n.jsxs)(l.A,{direction:"vertical",size:t?"small":"medium",style:{width:"100%"},children:[(0,n.jsxs)("div",{style:{display:"flex",flexDirection:t?"column":"row",gap:t?8:12},children:[(0,n.jsxs)("div",{style:{flex:2},children:[(0,n.jsx)(f,{style:{fontSize:t?11:12,color:"#fff",display:"block",marginBottom:t?3:6},children:"Full Name"}),(0,n.jsx)(c.A,{value:M,onChange:e=>R(e),placeholder:"Enter name...",style:{height:t?34:40,borderRadius:8,background:"var(--color-bg-1)"}})]}),(0,n.jsxs)("div",{style:{flex:1},children:[(0,n.jsx)(f,{style:{fontSize:t?11:12,color:"#fff",display:"block",marginBottom:t?3:6},children:"Age"}),(0,n.jsx)(c.A,{value:U,onChange:e=>P(e),placeholder:"Age...",type:"number",style:{height:t?34:40,borderRadius:8,background:"var(--color-bg-1)"}})]})]}),(0,n.jsxs)("div",{style:{display:"flex",flexDirection:t?"column":"row",gap:t?8:12},children:[(0,n.jsxs)("div",{style:{flex:1},children:[(0,n.jsx)(f,{style:{fontSize:t?11:12,color:"#fff",display:"block",marginBottom:t?3:6},children:"Gmail / Email"}),(0,n.jsx)(c.A,{value:D,onChange:e=>$(e),placeholder:"name@gmail.com",type:"email",style:{height:t?34:40,borderRadius:8,background:"var(--color-bg-1)"}})]}),(0,n.jsxs)("div",{style:{flex:1},children:[(0,n.jsx)(f,{style:{fontSize:t?11:12,color:"#fff",display:"block",marginBottom:t?3:6},children:"Phone Number"}),(0,n.jsx)(c.A,{value:O,onChange:e=>N(e),placeholder:"+1 234...",style:{height:t?34:40,borderRadius:8,background:"var(--color-bg-1)"}})]})]}),(0,n.jsxs)("div",{style:{background:"var(--color-bg-1)",border:"1px solid var(--color-border-2)",borderRadius:8,padding:t?8:12,maxHeight:t?65:110,overflowY:"auto",fontSize:11,lineHeight:1.5,color:"var(--color-text-3)"},children:[(0,n.jsx)(f,{bold:!0,style:{color:"#fff",display:"block",marginBottom:4},children:"Legal Notice & Policy"}),"RoyExt is a premium utility developed by Sohail Syed. This extension is designed solely for educational, testing, and personal productivity purposes. By activating and using this software, you agree that the developer (Sohail Syed) bears absolutely no responsibility or liability for any of your actions, queries, scripts executed, data processed, or any damages/consequences arising from the use of this extension. Use responsibly and in compliance with all relevant website terms of service."]}),(0,n.jsx)(u.A,{checked:I,onChange:e=>z(e),style:{fontSize:t?11:12},children:(0,n.jsx)("span",{style:{color:"var(--color-text-2)"},children:"I agree to the Legal Notice, Rules, and Policies"})}),(0,n.jsx)(d.A,{type:"primary",size:"large",loading:B,style:{width:"100%",height:t?38:44,borderRadius:8,background:"linear-gradient(135deg, #f7ba1e 0%, #d25f00 100%)",border:"none",fontWeight:700,color:"#fff",boxShadow:"0 4px 10px rgba(247, 186, 30, 0.2)"},onClick:K,children:"Activate RoyExt VIP"})]}):(0,n.jsxs)(l.A,{direction:"vertical",size:t?"small":"medium",style:{width:"100%",textAlign:"center"},children:[(0,n.jsxs)(y,{style:{color:"#d8b4fe",fontSize:t?12:14,lineHeight:1.6,marginTop:10},children:["Welcome, ",(0,n.jsx)("strong",{style:{color:"#fff"},children:M.trim()}),"!",(0,n.jsx)("br",{}),"All premium features are now unlocked. Enjoy your browsing experience!"]}),(0,n.jsx)(d.A,{type:"primary",size:"large",style:{width:"100%",height:t?38:44,borderRadius:8,background:"linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%)",border:"none",fontWeight:600,marginTop:12,boxShadow:"0 4px 10px rgba(124, 58, 237, 0.2)"},onClick:()=>{v(!1)},children:"Enter Extension"})]})]})})):(console.log("[VIPLock] Rendering unlocked children content."),(0,n.jsx)(n.Fragment,{children:e}))}},96306(e,t,r){"use strict";r.d(t,{Ay:()=>i,Dk:()=>c,LJ:()=>o,Qc:()=>l,Ze:()=>u,dw:()=>d,qK:()=>s,yI:()=>a});var n=r(64213);function i({size:e=16,style:t={},className:r=""}){return(0,n.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",xmlSpace:"preserve",width:e,height:e,version:"1.1",shapeRendering:"geometricPrecision",textRendering:"geometricPrecision",imageRendering:"optimizeQuality",fillRule:"evenodd",clipRule:"evenodd",viewBox:"0 0 360 511.48",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:(0,n.jsxs)("g",{id:"Layer_x0020_1",children:[(0,n.jsx)("polygon",{fill:"#D0401B",points:"144.83,306.61 296.28,280.53 360,429.51 281.2,428.61 216.45,481.14 "}),(0,n.jsx)("polygon",{fill:"#FF6600",points:"231.94,290.08 69.57,294.38 0,459.86 78.8,458.95 143.55,511.48"}),(0,n.jsx)("path",{fill:"#F5C800",d:"M183.21 0.03c9.35,-0.4 16.72,2.86 24.15,7.59 9.44,5.98 20.06,17.8 33.17,25.3 18.45,10.54 52.61,-4 70.11,21.99 10.21,15.16 10.69,27.04 11.45,38.78 0.82,12.67 3.04,24.32 16,41.47 21.47,28.38 25.94,47.27 14.88,66.96 -7.54,13.42 -23.41,20.88 -27.09,29.38 -7.81,18.09 0.83,31.72 -9.87,52.81 -7.43,14.62 -18.89,24.26 -34.16,29.18 -12.88,4.14 -25.8,-1.85 -36.1,2.48 -18.12,7.61 -31.48,25.3 -45.89,29.77 -5.57,1.73 -11.11,2.58 -16.65,2.54 -5.53,0.04 -11.08,-0.81 -16.64,-2.54 -14.42,-4.47 -27.78,-22.16 -45.9,-29.77 -10.3,-4.33 -23.22,1.66 -36.1,-2.48 -15.26,-4.92 -26.73,-14.56 -34.16,-29.18 -10.7,-21.09 -2.06,-34.72 -9.87,-52.81 -3.68,-8.5 -19.55,-15.96 -27.09,-29.38 -11.06,-19.69 -6.58,-38.58 14.88,-66.96 12.96,-17.15 15.18,-28.8 16,-41.47 0.76,-11.74 1.24,-23.62 11.45,-38.78 17.5,-25.99 51.66,-11.45 70.11,-21.99 13.12,-7.5 23.73,-19.32 33.17,-25.3 7.44,-4.73 14.81,-7.99 24.15,-7.59z"}),(0,n.jsx)("path",{fill:"#FFDD61",d:"M183.21 0.04c9.35,-0.41 16.71,2.86 24.15,7.58 9.44,5.98 20.06,17.8 33.17,25.3 14.67,8.38 39.28,0.91 57.54,10.56l-206.12 271.42c-2.45,-0.2 -4.92,-0.62 -7.38,-1.41 -15.27,-4.92 -26.73,-14.55 -34.16,-29.18 -10.7,-21.09 -2.06,-34.72 -9.87,-52.81 -3.68,-8.5 -19.55,-15.96 -27.09,-29.38 -11.06,-19.69 -6.58,-38.58 14.87,-66.96 12.97,-17.14 15.19,-28.8 16.01,-41.47 0.76,-11.74 1.24,-23.62 11.44,-38.78 17.51,-26 51.68,-11.45 70.12,-21.99 13.12,-7.5 23.74,-19.32 33.17,-25.3 7.44,-4.72 14.81,-7.99 24.15,-7.58z"}),(0,n.jsx)("circle",{fill:"#E37E00",cx:"182.71",cy:"176.83",r:"130.04"}),(0,n.jsx)("path",{fill:"#F5C800",d:"M182.71 72.88c57.41,0 103.94,46.54 103.94,103.95 0,57.41 -46.53,103.95 -103.94,103.95 -57.41,0 -103.95,-46.54 -103.95,-103.95 0,-57.41 46.54,-103.95 103.95,-103.95z"}),(0,n.jsx)("path",{fill:"#FFDD61",d:"M182.71 72.88c27.48,0 52.49,10.67 71.07,28.09l-127.44 163.2c-4.62,-2.98 -8.99,-6.33 -13.07,-9.99 -21.18,-19.02 -34.51,-46.63 -34.51,-77.35 0,-57.41 46.54,-103.95 103.95,-103.95z"}),(0,n.jsx)("path",{fill:"#E37E00","fill-rule":"nonzero",d:"M185.78 116.08l16.31 38.19 41.36 3.71c1.83,0.16 3.18,1.77 3.02,3.59 -0.07,0.89 -0.49,1.67 -1.12,2.21l0 0 -31.29 27.33 9.26 40.5c0.41,1.79 -0.71,3.57 -2.5,3.98 -0.92,0.21 -1.83,0.02 -2.56,-0.45l-35.55 -21.26 -35.66 21.32c-1.57,0.94 -3.61,0.43 -4.55,-1.14 -0.46,-0.77 -0.57,-1.64 -0.39,-2.45l0 0 9.26 -40.5 -31.3 -27.33c-1.38,-1.2 -1.52,-3.3 -0.31,-4.68 0.61,-0.7 1.46,-1.08 2.32,-1.13l41.26 -3.7 16.32 -38.21c0.72,-1.69 2.67,-2.47 4.35,-1.75 0.84,0.35 1.45,1 1.77,1.77l0 0z"})]})})}function o({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("path",{d:"M176 160c0-44.2 35.8-80 80-80s80 35.8 80 80",stroke:"#FFDD61",strokeWidth:"28",strokeLinecap:"round"}),(0,n.jsx)("path",{d:"M80 160h352c11 0 20 9 20 20v240c0 33.1-26.9 60-60 60H120c-33.1 0-60-26.9-60-60V180c0-11 9-20 20-20z",fill:"url(#shopBodyGrad)"}),(0,n.jsx)("circle",{cx:"256",cy:"300",r:"60",fill:"#E37E00"}),(0,n.jsx)("circle",{cx:"256",cy:"300",r:"48",fill:"#F5C800"}),(0,n.jsx)("path",{d:"M256 275l7 14 15 2-11 10 3 15-14-7-14 7 3-15-11-10 15-2z",fill:"#FFDD61"}),(0,n.jsx)("defs",{children:(0,n.jsxs)("linearGradient",{id:"shopBodyGrad",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#7c3aed"}),(0,n.jsx)("stop",{offset:"50%",stopColor:"#db2777"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#f7ba1e"})]})})]})}function s({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("circle",{cx:"256",cy:"256",r:"220",stroke:"url(#devBorderGrad)",strokeWidth:"24",fill:"url(#devBgGrad)"}),(0,n.jsx)("circle",{cx:"256",cy:"180",r:"64",fill:"#FFDD61"}),(0,n.jsx)("path",{d:"M136 380c0-66.3 53.7-120 120-120s120 53.7 120 120v20H136v-20z",fill:"#F5C800"}),(0,n.jsx)("path",{d:"M256 260l12 30-12 15-12-15z",fill:"#D0401B"}),(0,n.jsxs)("defs",{children:[(0,n.jsxs)("linearGradient",{id:"devBorderGrad",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#7c3aed"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#db2777"})]}),(0,n.jsxs)("linearGradient",{id:"devBgGrad",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"rgba(26, 15, 46, 0.4)"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"rgba(124, 58, 237, 0.2)"})]})]})]})}function a({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("rect",{width:"440",height:"440",x:"36",y:"36",rx:"90",fill:"url(#scriptBg)",stroke:"#FFDD61",strokeWidth:"18"}),(0,n.jsx)("path",{d:"M190 190l-70 66 70 66M322 190l70 66-70 66M280 160l-48 192",stroke:"#FFDD61",strokeWidth:"36",strokeLinecap:"round",strokeLinejoin:"round"}),(0,n.jsx)("defs",{children:(0,n.jsxs)("linearGradient",{id:"scriptBg",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#7c3aed"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#db2777"})]})})]})}function l({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("rect",{width:"440",height:"440",x:"36",y:"36",rx:"90",fill:"url(#subBg)",stroke:"#FFDD61",strokeWidth:"18"}),(0,n.jsx)("path",{d:"M160 130h192c11 0 20 9 20 20v252c0 13-15 20-24 12l-72-60-72 60c-9 8-24 1-24-12V150c0-11 9-20 20-20z",fill:"#FFDD61"}),(0,n.jsx)("defs",{children:(0,n.jsxs)("linearGradient",{id:"subBg",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#2563eb"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#0d9488"})]})})]})}function c({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("rect",{width:"440",height:"440",x:"36",y:"36",rx:"90",fill:"url(#logsBg)",stroke:"#FFDD61",strokeWidth:"18"}),(0,n.jsx)("path",{d:"M160 130h160l60 60v192c0 22-18 40-40 40H160c-22 0-40-18-40-40V170c0-22 18-40 40-40z",fill:"#FFDD61"}),(0,n.jsx)("path",{d:"M170 210h120M170 270h170M170 330h170",stroke:"#09070f",strokeWidth:"24",strokeLinecap:"round"}),(0,n.jsx)("defs",{children:(0,n.jsxs)("linearGradient",{id:"logsBg",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#059669"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#06b6d4"})]})})]})}function d({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("rect",{width:"440",height:"440",x:"36",y:"36",rx:"90",fill:"url(#toolsBg)",stroke:"#FFDD61",strokeWidth:"18"}),(0,n.jsx)("path",{d:"M344 140c-15.6-15.6-39.7-16.7-56.6-4.6l-50 50 20 56 56 20 50-50c12.1-16.9 11-41-4.6-56.6z",fill:"#FFDD61"}),(0,n.jsx)("path",{d:"M211 245l-95 95c-15.6 15.6-15.6 41 0 56.6s41 15.6 56.6 0l95-95",stroke:"#FFDD61",strokeWidth:"36",strokeLinecap:"round"}),(0,n.jsx)("defs",{children:(0,n.jsxs)("linearGradient",{id:"toolsBg",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#ea580c"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#eab308"})]})})]})}function u({size:e=16,style:t={},className:r=""}){return(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:e,viewBox:"0 0 512 512",fill:"none",style:{display:"inline-block",verticalAlign:"middle",...t},className:r,children:[(0,n.jsx)("rect",{width:"440",height:"440",x:"36",y:"36",rx:"90",fill:"url(#settingsBg)",stroke:"#FFDD61",strokeWidth:"18"}),(0,n.jsx)("circle",{cx:"256",cy:"256",r:"64",stroke:"#FFDD61",strokeWidth:"32"}),(0,n.jsx)("path",{d:"M256 96v40M256 376v40M96 256h40M376 256h40M143 143l28 28M341 341l28 28M143 341l28-28M341 143l28-28",stroke:"#FFDD61",strokeWidth:"36",strokeLinecap:"round"}),(0,n.jsx)("defs",{children:(0,n.jsxs)("linearGradient",{id:"settingsBg",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[(0,n.jsx)("stop",{offset:"0%",stopColor:"#dc2626"}),(0,n.jsx)("stop",{offset:"100%",stopColor:"#d946ef"})]})})]})}r(95217)},91823(e,t,r){"use strict";r.d(t,{A:()=>W});var n=r(64213);if(!/^(3295|5357|5788)$/.test(r.j))var i=r(10954);if(!/^(3295|5357|5788)$/.test(r.j))var o=r(87248);if(!/^(3295|5357|5788)$/.test(r.j))var s=r(51705);if(!/^(3295|5357|5788)$/.test(r.j))var a=r(9522);if(!/^(3295|5357|5788)$/.test(r.j))var l=r(67337);if(!/^(3295|5357|5788)$/.test(r.j))var c=r(37576);if(!/^(3295|5357|5788)$/.test(r.j))var d=r(56911);if(!/^(3295|5357|5788)$/.test(r.j))var u=r(97610);if(!/^(3295|5357|5788)$/.test(r.j))var h=r(9200);if(!/^(3295|5357|5788)$/.test(r.j))var p=r(38194);if(!/^(3295|5357|5788)$/.test(r.j))var g=r(79233);if(!/^(3295|5357|5788)$/.test(r.j))var m=r(94241);if(!/^(3295|5357|5788)$/.test(r.j))var f=r(56541);if(!/^(3295|5357|5788)$/.test(r.j))var y=r(22699);if(!/^(3295|5357|5788)$/.test(r.j))var b=r(21411);if(!/^(3295|5357|5788)$/.test(r.j))var x=r(61134);if(!/^(3295|5357|5788)$/.test(r.j))var v=r(15731);if(!/^(3295|5357|5788)$/.test(r.j))var w=r(56449);if(!/^(3295|5357|5788)$/.test(r.j))var k=r(35573);if(!/^(3295|5357|5788)$/.test(r.j))var j=r(84804);var _=r(95217);if(!/^(3295|5357|5788)$/.test(r.j))var S=r(38932);var C=r(66901);if(!/^(3295|5357|5788)$/.test(r.j))var A=r(59582);if(!/^(3295|5357|5788)$/.test(r.j))var E=r(18702);if(!/^(3295|5357|5788)$/.test(r.j))var T=r(877);var L=r(74525);if(!/^(3295|5357|5788)$/.test(r.j))var M=r(70731);if(!/^(3295|5357|5788)$/.test(r.j))var R=r(55984);if(!/^(3295|5357|5788)$/.test(r.j))var U=r(86774);if(!/^(3295|5357|5788)$/.test(r.j))var P=r(26861);if(!/^(3295|5357|5788)$/.test(r.j))var D=r(13049);if(!/^(3295|5357|5788)$/.test(r.j))var $=r(61301);if(!/^(3295|5357|5788)$/.test(r.j))var O=r(24747);if(!/^(3295|5357|5788)$/.test(r.j))var N=r(11879);if(!/^(3295|5357|5788)$/.test(r.j))var I=r(87330);if(!/^(3295|5357|5788)$/.test(r.j))var z=r(96306);let B=async e=>{try{let{hostname:t,pathname:r}=new URL(e.replace(/\/$/,""));if(!("scriptcat.org"===t&&/script-show-page\/\d+$/.test(r)))return e;{let e=r.match(/\d+$/)[0],{code:t,data:n,msg:i}=await fetch(`https://scriptcat.org/api/v2/scripts/${e}`).then(e=>e.json()).then(e=>e);if(0!==t)return{success:!1,msg:i};{let t=n.name;return`https://scriptcat.org/scripts/code/${e}/${t}.user.js`}}}catch{return e}},G=async e=>{let t=new TextEncoder().encode(e);return crypto.subtle.digest("SHA-1",t).then(e=>{let t=new Uint8Array(e),r="";for(let e=0;e<t.length;e++){let n=t[e];r+=`${n<16?"0":""}${n.toString(16)}`}return r})},F=async e=>{if(0==e.length)return;let t=await Promise.allSettled(e.map(async e=>{let t=await B(e);return t instanceof Object?await Promise.resolve(t):await T.fH.do("importByUrl",t)})),r={success:0,fail:0,msg:[]};return t.forEach(({value:e},t)=>{e.success?r.success++:(r.fail++,r.msg.push(`#${t+1}: ${e.msg}`))}),r},V=e=>(e=e.closest("button")?.parentNode||e,e=e.closest("span")?.parentNode||e,e=e.closest(".arco-form-item-control-children")?.parentNode||e,e=e.closest(".arco-collapse-item-content")?.parentNode||e,e=e.closest(".arco-card")?.parentNode||e,e=e.closest("aside")?.parentNode||e),H=_.memo(({active:e,text:t})=>e?(0,n.jsx)("div",{className:"sc-inset-0",style:{position:"absolute",zIndex:100,display:"flex",justifyContent:"center",alignItems:"center",color:"grey",fontSize:36,backdropFilter:"blur(4px)",background:"var(--color-fill-2)",opacity:.8},children:t}):null);H.displayName="DropzoneOverlay";let W=/^(3295|5357|5788)$/.test(r.j)?null:({children:e,className:t,pageName:r})=>{let[B,W]=i.A.useModal(),{colorThemeState:K,updateColorTheme:q}=(0,A.Us)(),J=(0,_.useRef)(null),[Y,X]=(0,_.useState)(!1),[Q,Z]=(0,_.useState)(!1),[ee,et]=(0,_.useState)([]),{t:er}=(0,C.Bd)(),en=e=>{e&&B.info({title:er("script_import_result"),content:(0,n.jsxs)(o.A,{direction:"vertical",style:{width:"100%"},children:[(0,n.jsx)("div",{style:{textAlign:"center"},children:(0,n.jsxs)(o.A,{size:"small",style:{fontSize:18},children:[(0,n.jsx)(m.A,{style:{color:"green"}}),e.success,"",(0,n.jsx)(f.A,{style:{color:"red"}}),e.fail]})}),e.msg.length>0&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("b",{children:er("failure_info")+":"}),e.msg]})]})})},ei=async e=>{let t=await F(e);t&&en(t)},eo=e=>{let t={success:0,fail:0,msg:[]};Promise.all(e.map(async e=>{try{let r=e.handle;if(!r)if(e instanceof FileSystemFileHandle)r=e;else if(e instanceof File){document.getElementById("import-local").value="";let r=new Blob([e],{type:"text/javascript"}),n=(0,$.xM)({blob:r,persistence:!1}),i=await T.fH.importByUrl(n);i.success?t.success++:(t.fail++,t.msg.push(...i.msg));return}else throw Error("Invalid Local File Access");let n=await r.getFile();if(!n.name||!n.size)throw Error("No Read Access Right for File");let i=await Promise.allSettled([n.text().then(e=>(0,P.jo)(e,`file:///*resp-check*/${n.name}`)),G(`f=${n.name}
s=${n.size},m=${n.lastModified}`)]);if("rejected"===i[0].status||!i[0].value||"rejected"===i[1].status)throw Error(er("script_import_failed"));let o=i[1].value;if(await (0,D.cC)(o,r),!window.open(`/src/install.html?file=${o}`,"_blank"))throw Error(er("install_page_open_failed"));t.success++}catch(e){t.fail++,t.msg.push(e.message)}})).then(()=>{en(t)})},{getRootProps:es,getInputProps:ea,isDragActive:el}=(0,L.VB)({accept:{"text/javascript":[".js"]},onDrop:eo,noClick:!0,noKeyboard:!0});(0,_.useEffect)(()=>{document.body.classList.toggle("dragzone-active",el)},[el]);let ec=(0,_.useMemo)(()=>[...Object.keys(R.Ay.store.data).map(e=>({key:e,title:R.Ay.store.data[e].title})),{key:"help",title:er("help_translate")}],[er]);(0,_.useEffect)(()=>{(0,R.ig)().then(e=>{e||Z(!0)})},[]),(0,_.useEffect)(()=>{"options"===r&&(async()=>{try{let e=await (0,I.Xh)();et(e)}catch(e){console.warn("Failed to load announcements in MainLayout:",e)}})()},[r]);let ed=async()=>{ei(J.current.dom.value.split(`
`).filter(e=>e)),X(!1)};return(0,n.jsx)(O.A,{parentNodeSelector:"#root",children:(0,n.jsx)(s.Ay,{renderEmpty:()=>(0,n.jsx)(a.A,{description:er("no_data")}),locale:(0,U.g)(R.Ay.language),componentConfig:{Select:{getPopupContainer:e=>V(e)}},getPopupContainer:e=>V(e.parentNode),children:(0,n.jsxs)(N.A,{children:[W,(0,n.jsxs)(l.A,{className:"tw-min-h-screen tw-relative tw-overflow-hidden",children:[(0,n.jsx)("div",{className:"futuristic-glow-orb orb-1"}),(0,n.jsx)("div",{className:"futuristic-glow-orb orb-2"}),(0,n.jsx)("div",{className:"futuristic-glow-orb orb-3"}),(0,n.jsxs)(l.A.Header,{style:{height:"50px"},className:"tw-flex tw-items-center tw-justify-between tw-px-4",children:[(0,n.jsx)(i.A,{title:er("import_link"),visible:Y,onOk:ed,onCancel:()=>{X(!1)},children:(0,n.jsx)(c.A.TextArea,{ref:J,rows:8,placeholder:er("import_script_placeholder"),defaultValue:"",onKeyDown:e=>{e.ctrlKey&&"Enter"===e.key&&(e.preventDefault(),ed())}})}),(0,n.jsxs)("div",{className:"tw-flex tw-flex-row tw-items-center",children:[(0,n.jsx)("img",{style:{height:"36px",marginRight:"8px"},src:"/assets/logo.png",alt:"RoyExt",className:"royext-logo-img"}),(0,n.jsx)("span",{className:"royext-logo-text",children:"RoyExt"})]}),"options"===r&&(0,n.jsxs)("div",{className:"header-nav-menu",children:[(0,n.jsxs)(S.k2,{to:"/",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.yI,{size:14})," ",(0,n.jsx)("span",{children:er("installed_scripts")})]}),(0,n.jsxs)(S.k2,{to:"/subscribe",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.Qc,{size:14})," ",(0,n.jsx)("span",{children:er("subscribe")})]}),(0,n.jsxs)(S.k2,{to:"/logger",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.Dk,{size:14})," ",(0,n.jsx)("span",{children:er("logs")})]}),(0,n.jsxs)(S.k2,{to:"/tools",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.dw,{size:14})," ",(0,n.jsx)("span",{children:er("tools")})]}),(0,n.jsxs)(S.k2,{to:"/setting",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.Ze,{size:14})," ",(0,n.jsx)("span",{children:er("settings")})]}),(0,n.jsxs)(S.k2,{to:"/vip",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.Ay,{size:14})," ",(0,n.jsx)("span",{children:"VIP"})]}),(0,n.jsxs)(S.k2,{to:"/shop",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.LJ,{size:14})," ",(0,n.jsx)("span",{children:"Vault"})]}),(0,n.jsxs)(S.k2,{to:"/developer",className:({isActive:e})=>`nav-tab-item ${e?"active":""}`,children:[(0,n.jsx)(z.qK,{size:14})," ",(0,n.jsx)("span",{children:"Developer"})]})]}),(0,n.jsxs)(o.A,{size:"small",className:"action-tools",children:["options"===r&&(0,n.jsx)(d.A,{droplist:(0,n.jsxs)(u.A,{style:{maxHeight:"100%",width:"calc(100% + 10px)"},children:[(0,n.jsx)(u.A.Item,{children:(0,n.jsxs)("a",{href:"#/script/editor",children:[(0,n.jsx)(E.$lf,{})," ",er("create_user_script")]})},"/script/editor"),(0,n.jsx)(u.A.Item,{children:(0,n.jsxs)("a",{href:"#/script/editor?template=background",children:[(0,n.jsx)(E.JVA,{})," ",er("create_background_script")]})},"background"),(0,n.jsx)(u.A.Item,{children:(0,n.jsxs)("a",{href:"#/script/editor?template=crontab",children:[(0,n.jsx)(E.jcj,{})," ",er("create_scheduled_script")]})},"crontab"),(0,n.jsxs)(u.A.Item,{onClick:()=>{"showOpenFilePicker"in window?window.showOpenFilePicker({multiple:!0,types:[{description:"JavaScript",accept:{"text/javascript":[".js"]}}]}).then(e=>{eo(e)}):document.getElementById("import-local")?.click()},children:[(0,n.jsx)(E.z4K,{})," ",er("import_by_local")]},"import_local"),(0,n.jsxs)(u.A.Item,{onClick:()=>{X(!0)},children:[(0,n.jsx)(y.A,{})," ",er("import_link")]},"link")]}),position:"bl",children:(0,n.jsxs)(h.A,{type:"primary",size:"small",className:"futuristic-action-btn",children:[(0,n.jsx)(E.ZLe,{})," ",er("create_script")," ",(0,n.jsx)(b.A,{})]})}),(0,n.jsx)(d.A,{droplist:(0,n.jsxs)(u.A,{onClickMenuItem:e=>{q(e)},selectedKeys:[K],children:[(0,n.jsxs)(u.A.Item,{children:[(0,n.jsx)(x.A,{})," ",er("light")]},"light"),(0,n.jsxs)(u.A.Item,{children:[(0,n.jsx)(v.A,{})," ",er("dark")]},"dark"),(0,n.jsxs)(u.A.Item,{children:[(0,n.jsx)(w.A,{})," ",er("system_follow")]},"auto")]}),position:"bl",children:(0,n.jsx)(h.A,{type:"text",size:"small",icon:(0,n.jsxs)(n.Fragment,{children:["auto"===K&&(0,n.jsx)(w.A,{}),"light"===K&&(0,n.jsx)(x.A,{}),"dark"===K&&(0,n.jsx)(v.A,{})]}),style:{color:"var(--color-text-1)"},className:"!tw-text-lg"})}),Q&&(0,n.jsx)(d.A,{droplist:(0,n.jsx)(u.A,{children:ec.map(e=>(0,n.jsx)(u.A.Item,{onClick:()=>{"help"===e.key?window.open("https://github.com/sohailsyedofficial/royext/discussions","_blank"):(M.EO.setLanguage(e.key),p.A.success(er("language_change_tip",{lng:e.key})))},children:e.title},e.key))}),children:(0,n.jsx)(h.A,{type:"text",size:"small",iconOnly:!0,icon:(0,n.jsx)(k.A,{}),style:{color:"var(--color-text-1)"},className:"!tw-text-lg"})})]})]}),"options"===r&&ee.length>0&&(0,n.jsx)("div",{style:{padding:"16px 24px 0 24px"},children:ee.map(e=>(0,n.jsx)(g.A,{type:"info",title:e.title,content:e.content,icon:(0,n.jsx)(j.A,{}),closable:!0,action:e.btn_text&&e.btn_link?(0,n.jsx)(h.A,{type:"primary",size:"small",style:{background:"linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%)",border:"none",borderRadius:6,color:"#fff"},onClick:()=>window.open(e.btn_link,"_blank"),children:e.btn_text}):void 0,style:{marginBottom:12,background:"rgba(124, 58, 237, 0.08)",border:"1px solid rgba(124, 58, 237, 0.2)",borderRadius:12}},e.id))}),(0,n.jsxs)(l.A,{className:`tw-bottom-0 tw-w-full ${t}`,style:{background:"var(--color-fill-2)"},...es({}),children:[(0,n.jsx)("input",{id:"import-local",...ea({style:{display:"none"}})}),(0,n.jsx)(H,{active:el,text:er("drag_script_here_to_upload")}),e]})]})]})})})}},24747(e,t,r){"use strict";r.d(t,{A:()=>o});var n=r(64213);let i=e=>{e.target.closest(".monaco-editor")?e.preventDefault():e.stopPropagation()};function o({children:e,parentNodeSelector:t}){var r;let s;return r=document.querySelector(t),s={capture:!1,passive:!1,once:!1},r?.removeEventListener("wheel",i,s),r?.addEventListener("wheel",i,s),(0,n.jsx)(n.Fragment,{children:e})}},80619(e,t,r){"use strict";r.d(t,{ON:()=>f,Q3:()=>y,R7:()=>b,e8:()=>x});var n=r(64213),i=r(95217);if(644==r.j)var o=r(9200);if(644==r.j)var s=r(12456);if(644==r.j)var a=r(87248);if(/^(5788|644|6905)$/.test(r.j))var l=r(22669);if(644==r.j)var c=r(32952);if(644==r.j)var d=r(62240);if(644==r.j)var u=r(99182);if(644==r.j)var h=r(37915);var p=r(66901);if(644==r.j)var g=r(70731);if(644==r.j)var m=r(61301);function f({script:e}){let t,{t:r}=(0,p.Bd)(),i=[];return(e.metadata.homepageurl||(t=function(e){try{if(e.includes("scriptcat.org")){let t=e.split("/")[5];return(0,n.jsx)(o.A,{type:"text",iconOnly:!0,size:"small",target:"_blank",href:`https://scriptcat.org/script-show-page/${t}`,children:(0,n.jsx)("img",{width:16,height:16,src:"/assets/logo.png",alt:""})})}if(e.includes("greasyfork.org")){let t=e.split("/")[4];return(0,n.jsx)(o.A,{type:"text",iconOnly:!0,size:"small",target:"_blank",href:`https://greasyfork.org/scripts/${t}`,children:(0,n.jsx)("img",{width:16,height:16,src:"/assets/logo/gf.png",alt:""})})}if(e.includes("raw.githubusercontent.com")||e.includes("github.com")){let t=`${e.split("/")[3]}/${e.split("/")[4]}`;return(0,n.jsx)(o.A,{type:"text",iconOnly:!0,size:"small",target:"_blank",href:`https://github.com/${t}`,style:{color:"var(--color-text-1)"},icon:(0,n.jsx)(c.A,{})})}}catch(e){console.error(e)}}(e.downloadUrl||"")),t&&i.push((0,n.jsx)(s.A,{content:r("homepage"),children:t})),e.metadata.homepage&&i.push((0,n.jsx)(s.A,{content:r("homepage"),children:(0,n.jsx)(o.A,{type:"text",iconOnly:!0,icon:(0,n.jsx)(d.A,{}),size:"small",href:e.metadata.homepage[0],target:"_blank"})})),e.metadata.homepageurl&&i.push((0,n.jsx)(s.A,{content:r("homepage"),children:(0,n.jsx)(o.A,{type:"text",iconOnly:!0,icon:(0,n.jsx)(d.A,{}),size:"small",href:e.metadata.homepageurl[0],target:"_blank"})})),e.metadata.website&&i.push((0,n.jsx)(s.A,{content:r("script_website"),children:(0,n.jsx)(o.A,{type:"text",iconOnly:!0,icon:(0,n.jsx)(d.A,{}),size:"small",href:e.metadata.website[0],target:"_blank"})})),e.metadata.source&&i.push((0,n.jsx)(s.A,{content:r("script_source"),children:(0,n.jsx)(o.A,{type:"text",iconOnly:!0,icon:(0,n.jsx)(u.A,{}),size:"small",href:e.metadata.source[0],target:"_blank"})})),e.metadata.supporturl&&i.push((0,n.jsx)(s.A,{content:r("bug_feedback_script_support"),children:(0,n.jsx)(o.A,{type:"text",iconOnly:!0,icon:(0,n.jsx)(h.A,{}),size:"small",href:e.metadata.supporturl[0],target:"_blank"})})),0===i.length)?null:(0,n.jsx)(a.A,{size:"mini",children:i.map((e,t)=>(0,n.jsx)("i",{children:e},t))})}function y({script:e,size:t=32,style:r}){let[o,s]=(0,i.useState)(!1);(r=r||{}).display=r.display||"inline-block",r.marginRight=r.marginRight||"8px",r.backgroundColor=r.backgroundColor||"unset";let a=e.metadata,[c]=a.icon||a.iconurl||a.icon64||a.icon64url||[];return c&&!o?(0,n.jsx)(l.A,{size:t||32,shape:"square",style:r,children:(0,n.jsx)("img",{src:c,alt:e?.name,onError:()=>s(!0)})}):(0,n.jsx)(n.Fragment,{})}function b(e){let[t,r]=(0,i.useState)(()=>{let t=`default${(0,m.Cb)(e)}`,n=g.EO[t],i="function"==typeof n?n():void 0;return Promise.resolve(g.EO.get(e)).then(e=>r(e)),i}),n=(0,i.useRef)(t=>{void 0===t?r(t=>(g.EO.set(e,t),t)):(g.EO.set(e,t),r(t))}).current;return(0,i.useEffect)(()=>g.EO.addListener(e,e=>{r(e)}),[e]),[t,r,n]}function x(e){if(!e)return"gray";let t=["red","orangered","orange","gold","lime","green","cyan","arcoblue","purple","pinkpurple","magenta","gray"],r=5381;for(let t=0,n=e.length;t<n;t++)r=33*r^e.charCodeAt(t);let n=(r>>>=0)%t.length;return t[n]}},59582(e,t,r){"use strict";r.d(t,{CB:()=>a,Dv:()=>u,Us:()=>h});var n=r(64213),i=r(95217);if(!/^(3295|5357)$/.test(r.j))var o=r(70731);if(!/^(3295|5357)$/.test(r.j))var s=r(21794);let a=/^(3295|5357)$/.test(r.j)?null:{setEditorTheme:null},l=/^(3295|5357)$/.test(r.j)?null:(0,i.createContext)(void 0),c=!1,d=e=>{switch("dark"!==e&&"light"!==e?(e=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light",c=!0):c=!1,e){case"dark":document.documentElement.classList.add("dark"),document.body.setAttribute("arco-theme","dark"),a.setEditorTheme?.("vs-dark");break;case"light":document.documentElement.classList.remove("dark"),document.body.removeAttribute("arco-theme"),a.setEditorTheme?.("vs")}},u=({children:e})=>{let[t,r]=(0,i.useState)(()=>(d(localStorage.lightMode),window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{c&&d("auto")}),localStorage.lightMode||"auto")),[a,u]=(0,i.useState)(!1);return(0,i.useEffect)(()=>{let e=new s.b;return e.append((0,o.o)("onColorThemeUpdated",{onColorThemeUpdated({theme:e}){d(e),r(e)}}.onColorThemeUpdated)),e.unhook},[]),(0,n.jsx)(l.Provider,{value:{colorThemeState:t,updateColorTheme:e=>{localStorage.lightMode=e,o.JD.publish("onColorThemeUpdated",{theme:e})},setGuideMode:u,guideMode:a},children:e})};function h(){let e=(0,i.useContext)(l);if(!e)throw Error("useAppContext must be used within an AppProvider");return e}},70731(e,t,r){"use strict";r.d(t,{EO:()=>c,Eb:()=>d,JD:()=>l,iU:()=>u,o:()=>h});var n=r(73161),i=r(38215),o=r(48099),s=r(55984),a=r(89043);let l=new n.j,c=new i.GL(l),d=new Map,u=new o.Dz;new a.XW(u);let h=(e,t)=>l.subscribe(e,e=>{let r=e?.myMessage||e;"object"==typeof r&&t(r)});(0,s.sg)(c)},12725(e,t,r){"use strict";r.d(t,{A:()=>n});class n{prefix;storage;constructor(e,t){this.prefix=`${e}_`,this.storage=t?chrome.storage.sync:chrome.storage.local}buildKey(e){return this.prefix+e}get(e){return new Promise(t=>{e=this.buildKey(e),this.storage.get(e,r=>{t(r&&r[e])})})}set(e,t){return new Promise(r=>{let n={};n[this.buildKey(e)]=t,this.storage.set(n,()=>r())})}remove(e){return new Promise(t=>{this.storage.remove(this.buildKey(e),()=>t())})}removeAll(){return new Promise(e=>{this.storage.clear(()=>e())})}keys(){return new Promise(e=>{let t={},r=this.buildKey("");this.storage.get(n=>{if(!n)return e(t);for(let e of Object.keys(n))e.startsWith(r)&&(t[e.substring(r.length)]=n[e]);return e(t)})})}}},38215(e,t,r){"use strict";if(r.d(t,{GF:()=>h,GL:()=>p,Pm:()=>f}),!/^(3295|5357)$/.test(r.j))var n=r(12725);if(!/^(3295|5357)$/.test(r.j))var i=r(14845);if(!/^(3295|5357)$/.test(r.j))var o=r(56716);if(!/^(3295|5357)$/.test(r.j))var s=r(55984);if(!/^(3295|5357)$/.test(r.j))var a=r(23512);if(!/^(3295|5357)$/.test(r.j))var l=r(76729);if(!/^(3295|5357)$/.test(r.j))var c=r(61301);var d=r(80413);if(!/^(3295|5357)$/.test(r.j))var u=r(60625);let h="systemConfigChange";class p{mq;cache=new Map;syncStorage=new n.A("system",!0);localStorage=new n.A("system",!1);isLocalKey(e){return u.n.has(e)}getStorage(e){return this.isLocalKey(e)?this.localStorage:this.syncStorage}EE=new d.A;constructor(e){this.mq=e,this.mq.subscribe(h,({key:e,value:t,prev:r})=>{this.cache.set(e,t),this.EE.emit(e,t,r)})}addListener(e,t){return this.EE.on(e,t),this.EE.off.bind(this.EE,e,t)}watch(e,t){return this.get(e).then(e=>{t(e,void 0)}),this.addListener(e,t)}resolveDefault(e){return e?.asyncValue?.()||e}async transferSyncToLocal(e,t){let r=await this.syncStorage.get(e);return void 0===r?(this.cache.set(e,void 0),this.resolveDefault(t)):(await this.syncStorage.remove(e),await this.localStorage.set(e,r),this.cache.set(e,r),r)}_get(e,t){if(this.cache.has(e)){let r=this.cache.get(e);return Promise.resolve(void 0===r?this.resolveDefault(t):r)}return this.getStorage(e).get(e).then(r=>void 0!==r?(this.cache.set(e,r),r):this.isLocalKey(e)?this.transferSyncToLocal(e,t):(this.cache.set(e,r),this.resolveDefault(t)))}get(e){let t=`get${(0,c.Cb)(e)}`;if("function"==typeof this[t])return this[t]();throw Error(`Method ${t} does not exist on SystemConfig`)}set(e,t){let r=`set${(0,c.Cb)(e)}`;if("function"==typeof this[r])this[r](t);else throw Error(`Method ${r} does not exist on SystemConfig`)}_set(e,t){let r,n=this.cache.get(e),i=this.getStorage(e);void 0===t?(this.cache.delete(e),r=i.remove(e)):(this.cache.set(e,t),r=i.set(e,t)),r.then(()=>{this.mq.publish(h,{key:e,value:t,prev:n})})}defaultCheckScriptUpdateCycle(){return 86400}getCheckScriptUpdateCycle(){return this._get("check_script_update_cycle",this.defaultCheckScriptUpdateCycle())}setCheckScriptUpdateCycle(e){this._set("check_script_update_cycle",e)}getSilenceUpdateScript(){return this._get("silence_update_script",!1)}setSilenceUpdateScript(e){this._set("silence_update_script",e)}getEnableAutoSync(){return this._get("enable_auto_sync",!0)}setEnableAutoSync(e){this._set("enable_auto_sync",e)}getUpdateDisableScript(){return this._get("update_disable_script",!0)}setUpdateDisableScript(e){this._set("update_disable_script",e)}getVscodeUrl(){return this._get("vscode_url","ws://localhost:8642")}setVscodeUrl(e){this._set("vscode_url",e)}getVscodeReconnect(){return this._get("vscode_reconnect",!1)}setVscodeReconnect(e){this._set("vscode_reconnect",e)}defaultBackup(){return{filesystem:"webdav",params:{}}}getBackup(){return this._get("backup",this.defaultBackup())}setBackup(e){this._set("backup",e)}defaultCloudSync(){return{enable:!1,syncDelete:!1,syncStatus:!0,filesystem:"webdav",params:{}}}getCloudSync(){return this._get("cloud_sync",this.defaultCloudSync())}setCloudSync(e){this._set("cloud_sync",e)}defaultCatFileStorage(){return{status:"unset",filesystem:"webdav",params:{}}}getCatFileStorage(){return this._get("cat_file_storage",this.defaultCatFileStorage())}setCatFileStorage(e){this._set("cat_file_storage",e)}getEnableEslint(){return this._get("enable_eslint",!0)}setEnableEslint(e){this._set("enable_eslint",e)}getEslintConfig(){return this._get("eslint_config",i.s)}setEslintConfig(e){return""===e?void this._set("eslint_config",i.s):(JSON.parse(e),this._set("eslint_config",e))}getEditorConfig(){return this._get("editor_config",o.s)}setEditorConfig(e){return""===e?void this._set("editor_config",o.s):(JSON.parse(e),this._set("editor_config",e))}getEditorTypeDefinition(){return localStorage.getItem("editor_type_definition")||l}setEditorTypeDefinition(e){""===e?delete localStorage.editor_type_definition:localStorage.setItem("editor_type_definition",e)}getLogCleanCycle(){return this._get("log_clean_cycle",7)}setLogCleanCycle(e){this._set("log_clean_cycle",e)}getScriptListColumnWidth(){return this._get("script_list_column_width",{})}setScriptListColumnWidth(e){this._set("script_list_column_width",e)}defaultMenuExpandNum(){return 5}getMenuExpandNum(){return this._get("menu_expand_num",this.defaultMenuExpandNum())}setMenuExpandNum(e){this._set("menu_expand_num",e)}async getLanguage(){if(globalThis.localStorage){let e=localStorage.getItem("language");if(e)return e}return this._get("language",{asyncValue:()=>(0,s.ig)().then(e=>e||chrome.i18n.getUILanguage())}).then(e=>(globalThis.localStorage&&localStorage.setItem("language",`${e}`),e))}setLanguage(e){this._set("language",e),globalThis.localStorage&&localStorage.setItem("language",e)}setCheckUpdate(e){this._set("check_update",{notice:e.notice,version:e.version,isRead:e.isRead})}async getCheckUpdate(e){let t=await this._get("check_update",{notice:"",isRead:!1,version:a.eg});return"function"==typeof e?.sanitizeHTML&&(t.notice=e.sanitizeHTML(t.notice)),t}setEnableScript(e){chrome.extension.inIncognitoContext?this._set("enable_script_incognito",e):this._set("enable_script",e)}async getEnableScript(){if(!chrome.extension.inIncognitoContext)return this._get("enable_script",!0);{let[e,t]=await Promise.all([this._get("enable_script",!0),this._get("enable_script_incognito",!0)]);return e&&t}}async getEnableScriptNormal(){return this._get("enable_script",!0)}async getEnableScriptIncognito(){return this._get("enable_script_incognito",!0)}setBlacklist(e){this._set("blacklist",e)}getBlacklist(){return this._get("blacklist","")}setBadgeNumberType(e){this._set("badge_number_type",e)}getBadgeNumberType(){return this._get("badge_number_type","script_count")}setBadgeBackgroundColor(e){this._set("badge_background_color",e)}getBadgeBackgroundColor(){return this._get("badge_background_color","#4e5969")}setBadgeTextColor(e){this._set("badge_text_color",e)}getBadgeTextColor(){return this._get("badge_text_color","#ffffff")}setScriptMenuDisplayType(e){this._set("script_menu_display_type",e)}getScriptMenuDisplayType(){return this._get("script_menu_display_type","all")}}let g="",m=0,f=e=>(g||(g=((1213056*Math.random()|0)+466560).toString(36).toUpperCase()),e=e.replace(/@name\s+(New Userscript)[\r\n]/g,(e,t)=>e.replace(t,`${t} ${g}-${++m}`)))},60625(e,t,r){"use strict";r.d(t,{n:()=>n});let n=new Set(["cloud_sync","backup","cat_file_storage","vscode_url","vscode_reconnect","language","script_list_column_width","check_update","enable_script","enable_script_incognito"])},392(e,t,r){"use strict";r.d(t,{e:()=>o});let n=/^(4259|5788|9518)$/.test(r.j)?null:{},i=async e=>{let t;for(;t=e.head;){let{task:r,resolve:n,reject:i}=t;t.task=t.resolve=t.reject=null;try{let e=await r();n(e)}catch(e){i(e)}e.head=t.next,t.next=null}e.tail=null},o=(e,t)=>new Promise((r,o)=>{let s=n[e]||(n[e]={head:null,tail:null}),a={task:t,resolve:r,reject:o,next:null};s.tail?(s.tail.next=a,s.tail=a):(s.head=a,s.tail=a,i(s))})},59886(e,t,r){"use strict";r.d(t,{nT:()=>a,xG:()=>l});var n=r(95901);if(!/^(3295|5788)$/.test(r.j))var i=r(40403);let o=new n.CronTime("* * * * *").sendAt().constructor,s=/^6(44|905)$/.test(r.j)?{1:{unit:"minute",format:"yyyy-MM-dd HH:mm:ss",label:"minute"},2:{unit:"hour",format:"yyyy-MM-dd HH:mm:ss",label:"hour"},3:{unit:"day",format:"yyyy-MM-dd",label:"day"},4:{unit:"month",format:"yyyy-MM",label:"month"},5:{unit:"week",format:"yyyy-MM-dd",label:"week"}}:null,a=(e,t=new Date)=>{try{let r=c(e,t),n=r.next.toFormat(r.format);return r.once?(0,i.t)(`cron_oncetype.${r.once}`,{next:n}):n}catch(t){return console.error(`nextTimeDisplay: Invalid cron expression "${e}"`,t),(0,i.t)("cron_invalid_expr")}},l=e=>{let t=e.trim().split(" "),r=+(5===t.length);if(t.length+r!==6)throw Error((0,i.t)("cron_invalid_expr"));let n=-1;for(let e=0;e<t.length;e++){let i=t[e];if(i.startsWith("once")){n=e+r,t[e]=i.slice(5,-1)||"*";break}}return{cronExpr:t.join(" "),oncePos:n}},c=(e,t=new Date)=>{let r,{cronExpr:a,oncePos:c}=l(e);try{r=new n.CronTime(a)}catch{throw Error((0,i.t)("cron_invalid_expr"))}let d=o.fromJSDate(t),u="yyyy-MM-dd HH:mm:ss",h="";if(c>=1&&c<=5){let e=s[c];h=e.label,u=e.format,d=(d=d.plus({[e.unit]:1}).startOf(e.unit)).minus({milliseconds:1})}return{next:r.getNextDateFrom(d),format:u,once:h}}},29106(e,t,r){"use strict";function n(e){return o(new Date(1e3*e),"YYYY-MM-DD HH:mm:ss")}r.d(t,{H:()=>n,U:()=>o});let i=/YYYY|MM|DD|HH|mm|ss/g;function o(e=new Date,t="YYYY-MM-DD HH:mm:ss"){return t.replace(i,t=>{switch(t){case"YYYY":return e.getFullYear().toString();case"MM":{let t=e.getMonth()+1;return t<10?"0"+t:t.toString()}case"DD":{let t=e.getDate();return t<10?"0"+t:t.toString()}case"HH":{let t=e.getHours();return t<10?"0"+t:t.toString()}case"mm":{let t=e.getMinutes();return t<10?"0"+t:t.toString()}case"ss":{let t=e.getSeconds();return t<10?"0"+t:t.toString()}}return t})}},77939(e,t,r){"use strict";r.d(t,{mj:()=>m});var n=r(41720),i=r.n(n);let o=(e,t=!0)=>{if(!(e instanceof Uint8Array))throw TypeError("utf32Bytes must be a Uint8Array");let r=e.byteLength;if(r%4!=0)throw RangeError("UTF-32 byte length must be a multiple of 4");let n=new DataView(e.buffer,e.byteOffset,r),i="",o=[];for(let e=0;e<r;e+=4){let r=n.getUint32(e,t);(0!==e||65279!==r)&&(o.push(r),o.length>=16384&&(i+=String.fromCodePoint(...o),o=[]))}return o.length&&(i+=String.fromCodePoint(...o)),i},s=(e,t)=>{let r=e.toLowerCase();return"utf-32le"===r?o(t,!0):"utf-32be"===r?o(t,!1):new TextDecoder(r).decode(t)},a=new Set(["utf-8","ascii","utf-16le","utf-16be","utf-32le","utf-32be"]),l=/^(3295|5357|5788)$/.test(r.j)?null:16384,c=/^(3295|5357|5788)$/.test(r.j)?null:262144,d=8,u=/^(3295|5357|5788)$/.test(r.j)?null:32768,h=/^(3295|5357|5788)$/.test(r.j)?null:131072,p=e=>(192&e)==128,g=(e,t,r,n)=>{let i=t.length;if(0===i)return;let o=Math.max(0,Math.min(r,i)),s=Math.max(o,Math.min(n,i));for(;o>0&&p(t[o]);)o--;for(;s<i&&p(t[s]);)s++;o>=s||e.some(([e,t])=>o>=e&&s<=t)||e.push([o,s])},m=async(e,t)=>{let r;if(0===(r=ArrayBuffer.isView(e)?new Uint8Array(e.buffer,e.byteOffset,e.byteLength):new Uint8Array(await e.arrayBuffer())).length)return"";let n=(e=>{if(!e)return"";let t=/charset\s*=\s*["']?([^"';\s]+)/i.exec(e);return t?t[1].toLowerCase():""})(t);if(n)try{return s(n,r)}catch(e){console.warn(`Invalid charset from Content-Type header: ${n}, error: ${e.message}`)}let o=239===r[0]&&187===r[1]&&191===r[2]?"utf-8":255===r[0]&&254===r[1]?0===r[2]&&0===r[3]?"utf-32le":"utf-16le":254===r[0]&&255===r[1]?"utf-16be":0===r[0]&&0===r[1]&&254===r[2]&&255===r[3]?"utf-32be":null;if(o)return s(o,r);let p=Math.min(r.length,l),m=function(e,t=e.length){if(t<64)return null;let r=[0,0,0,0];for(let n=0;n<t;n++)0===e[n]&&r[3&n]++;let n=r[0]+r[1]+r[2]+r[3];if(n<.07*t)return null;let i=n/t;if(e.length%4==0&&i>.54){let e=t/4,n=.65*e,i=.35*e;if(r[0]<i&&r[1]>n&&r[2]>n&&r[3]>n)return"utf-32le";if(r[0]>n&&r[1]>n&&r[2]>n&&r[3]<i)return"utf-32be"}if(e.length%2==0&&i>.1){let e=r[0]+r[2],t=r[1]+r[3];if(e>4.2*t)return"utf-16be";if(t>4.2*e)return"utf-16le";if(e>2.1*t&&i>.2)return"utf-16be";if(t>2.1*e&&i>.2)return"utf-16le"}return null}(r,p);if(m&&((e,t)=>{try{let r=t.subarray(0,Math.min(h,t.length)),n=s(e,r);return!(e=>{let t=0;for(let r=0;r<e.length;r++){let n=e.charCodeAt(r);if(65533===n||0===n)return!0;n<32&&9!==n&&10!==n&&13!==n&&t++}return t>Math.max(4,.02*e.length)})(n)}catch{return!1}})(m,r))try{return s(m,r)}catch{}let f="utf-8";try{(e=>{if(e.length<=c)return new TextDecoder("utf-8",{fatal:!0}).decode(e);let t=new TextDecoder("utf-8",{fatal:!0});for(let[r,n]of((e,t=l,r=d)=>{let n=e.length;if(n<=t)return[[0,n]];let i=[],o=n>>>1,s=t>>>1;g(i,e,0,t),g(i,e,Math.max(0,o-s),Math.min(n,o+s)),g(i,e,Math.max(0,n-t),n);let a=t;for(;i.length<r&&a<n;){let r=-1;for(let t=a;t<n;t++)if(e[t]>=128){r=t;break}if(r<0)break;let o=Math.max(0,r-s),l=Math.min(e.length,o+t);g(i,e,o,l),a=Math.max(r+t,l)}return i.sort((e,t)=>e[0]-t[0])})(e))t.decode(e.subarray(r,n))})(r)}catch{let e=(e=>{let t=new TextDecoder("utf-8").decode(e),r=0,n=0;for(let e=0;e<t.length;e++){let i=t.charCodeAt(e);65533===i?r++:i>127&&n++}return n>=4*r&&r>0&&r<=8?t:null})(r);if(null!==e)return e;f=(e=>{let t=(e=>{let t=e.length;if(t<=u)return e;let r=-1;for(let n=0;n<t;n++)if(e[n]>=128){r=n;break}if(r<0)return e.subarray(0,u);let n=Math.max(0,Math.min(r-8192,t-u));return e.subarray(n,n+u)})(e),r=i().analyse(t).sort((e,t)=>t.confidence-e.confidence),n=-1,o=[],l=1/0;for(let e of r){let r,i=e.name.toLowerCase();if(a.has(i))continue;try{r=s(i,t)}catch{}if(!r)continue;if(n<0){if((n=e.confidence)>90)return i}else if(n>70&&e.confidence<30)break;else if(n>50&&e.confidence<20)break;let c=new Set(r),d=c.size;!(d>l)&&(c.has("�")&&(d+=Math.max(r.split("�").length-1,1)),o.push({encoding:i,charLen:d}),d<l&&(l=d))}let c=o.find(e=>e.charLen===l);return c?.encoding||"windows-1252"})(r)}return s(f,r)}},13049(e,t,r){"use strict";r.d(t,{Vj:()=>a,cC:()=>s,fc:()=>l});var n=r(18075);class i extends n.Ay{handles;constructor(){super("filehandle-temp-dexie"),this.version(1).stores({handles:""}),this.handles=this.table("handles")}}let o=new i;async function s(e,t){await o.handles.put({handle:t,timestamp:Date.now()},e)}async function a(e){let t=await o.handles.get(e);if(t?.handle instanceof FileSystemFileHandle)return t.handle;throw Error("Handle not found or invalid")}async function l(e=9e5){let t=Date.now();await o.handles.filter(r=>t-r.timestamp>e).delete()}},21794(e,t,r){"use strict";r.d(t,{b:()=>n});class n{isMounted=!0;unhooks=[];append(...e){this.unhooks?.push(...e)}unhook=()=>{if(this.isMounted=!1,null!==this.unhooks){for(let e of this.unhooks)e();this.unhooks.length=0,this.unhooks=null}}}},96349(e,t,r){"use strict";r.d(t,{G2:()=>o,_8:()=>s});let n=[1],i=[2],o=e=>{switch(e[0]){case 1:return;case 2:return null;default:return e[1]}},s=e=>{switch(e){case void 0:return n;case null:return i;default:return[0,e]}}},56716(e,t,r){"use strict";r.d(t,{s:()=>n});let n=JSON.stringify({noSemanticValidation:!0,noSyntaxValidation:!1,onlyVisible:!1,allowNonTsExtensions:!0,allowJs:!0,checkJs:!0,noUnusedLocals:!1,noFallthroughCasesInSwitch:!1,noImplicitThis:!1,strict:!0},null,2)},89444(e,t,r){"use strict";r.d(t,{A:()=>d,v:()=>u});var n=r(70731),i=r(80413),o=r(82905);if(/^6(44|905)$/.test(r.j))var s=r(80993);let a=new Worker("/src/linter.worker.js"),l=n.EO.getLanguage(),c={"zh-CN":{title:"简体中文",thisIsAUserScript:"一个用户脚本",undefinedPrompt:"未定义的提示符",quickfix:"修复 {0} 问题",addEslintDisableNextLine:"添加 eslint-disable-next-line 注释",addEslintDisable:"添加 eslint-disable 注释",declareGlobal:"将 '{0}' 声明为全局变量 (/* global */)",prompt:{name:"脚本名称",namespace:"脚本命名空间",copyright:"脚本的版权信息",license:"脚本的开源协议",version:"脚本版本",description:"脚本描述",icon:"脚本图标",iconURL:"脚本图标",defaulticon:"脚本图标",icon64:"64x64 大小的脚本图标",icon64URL:"64x64 大小的脚本图标",grant:"脚本特殊 Api 权限申请",author:"脚本作者","run-at":"脚本的运行时间<br>`document-start`：在前端匹配到网址后，以最快的速度注入脚本到页面中<br>`document-end`：DOM 加载完成后注入脚本，此时页面脚本和图像等资源可能仍在加载<br>`document-idle`：所有内容加载完成后注入脚本<br>`document-body`：脚本只会在页面中有 body 元素时才会注入","run-in":"脚本注入的环境",homepage:"脚本主页",homepageURL:"脚本主页",website:"脚本主页",background:"后台脚本",include:"脚本匹配 url 运行的页面",match:"脚本匹配 url 运行的页面",exclude:"脚本匹配 url 不运行的页面",connect:"获取网站的访问权限",resource:"引入资源文件",require:"引入外部 js 文件","require-css":"引入外部 css 文件",noframes:"表示脚本不运行在 `<frame>` 中",compatible:"用于在 GreasyFork 中显示脚本的兼容性支持","inject-into":"脚本注入环境<br>`content`：脚本注入到 content 环境<br>`page`：脚本注入到网页环境（默认）<br>注：SC 不支持以 CSP 判断是否需要脚本注入到 content 环境的 `inject-into: auto` 设计。","early-start":"配合 `run-at: document-start` 的声明，使用 `early-start` 可以比网页更快地加载并执行脚本，但存在一定性能问题与 GM API 使用限制。（SC 独有）",definition:"RoyExt 特有功能：一个 `.d.ts` 文件的引用地址，能够自动补全编辑器的提示",antifeature:`与脚本市场有关，不受欢迎的功能需要加上此描述值
referral-link：该脚本会修改或重定向到作者的返佣链接
ads：该脚本会在访问的页面上插入广告
payment：该脚本需要付费才能够正常使用
miner：该脚本存在利用用户资源但不为用户产生收益或收益极其微弱的行为
membership：该脚本需要注册会员/关注公众号才能正常使用
tracking：该脚本会追踪你的用户信息`.replace(/\n/g,"<br>"),updateURL:"脚本检查更新的 url",downloadURL:"脚本更新的下载地址",supportURL:"支持站点、bug 反馈页面",source:"脚本源码页",crontab:`定时脚本 crontab 参考（不适用于云端脚本）
* * * * * * 每秒运行一次
* * * * * 每分钟运行一次
0 */6 * * * 每 6 小时的 0 分执行一次
15 */6 * * * 每 6 小时的 15 分执行一次
* once * * * 每小时运行一次
* * once * * 每天运行一次
* 10 once * * 每天 10:00-10:59 运行一次，若 10:04 已运行，本日 10:05-10:59 不再运行
* 1,3,5 once * * 每天 1/3/5 点运行一次，若 1 点已运行，当天 3、5 点不再运行
* */4 once * * 每隔 4 小时检测并运行一次，若 4 点已运行，当天 8/12/16/20/24 点不再运行
* 10-23 once * * 每天 10:00-23:59 运行一次，若 10:04 已运行，当日 10:05-23:59 不再运行
* once 13 * * 每个月 13 号的每小时运行一次`.replace(/\n/g,"<br>")}},"en-US":{title:"English",thisIsAUserScript:"A user script",undefinedPrompt:"Undefined Prompt",quickfix:"Fix {0} Issue",addEslintDisableNextLine:"Add eslint-disable-next-line Comment",addEslintDisable:"Add eslint-disable Comment",declareGlobal:"Declare '{0}' as a global variable (/* global */)",prompt:{name:"Script name",namespace:"Script namespace",copyright:"Script copyright information",license:"Script open-source license",version:"Script version",description:"Script description",icon:"Script icon",iconURL:"Script icon",defaulticon:"Script icon",icon64:"64x64 script icon",icon64URL:"64x64 script icon",grant:"Request special script API permissions",author:"Script author","run-at":"When the script runs<br>`document-start`: inject as early as possible after URL match<br>`document-end`: inject after DOM has loaded (images etc. may still load)<br>`document-idle`: inject after all content has finished loading<br>`document-body`: inject only when a body element exists","run-in":"Environment in which the script is injected",homepage:"Script homepage",homepageURL:"Script homepage",website:"Script homepage",background:"Background script",include:"Pages whose URLs match and run this script",match:"Pages whose URLs match and run this script",exclude:"Pages whose URLs match and do NOT run this script",connect:"Sites the script can access",resource:"Imported resource files",require:"Imported external JS files","require-css":"Imported external CSS files",noframes:"Do not run the script inside `<frame>`",compatible:"Compatibility information shown on GreasyFork","inject-into":"Script injection context<br>`content`: inject into content context<br>`page`: inject into page context (default)<br>Note: SC does not support `inject-into: auto`, which chooses context based on CSP.","early-start":"Used with `run-at: document-start`. `early-start` lets the script execute even earlier than the page, but may affect performance and limit GM APIs. (SC only)",definition:"RoyExt-only: URL of a `.d.ts` file used for editor auto-completion",antifeature:"For script markets: describe any unwanted or controversial features",updateURL:"URL used to check for script updates",downloadURL:"URL used to download script updates",supportURL:"Support site / bug report page",source:"Script source code page",crontab:`Scheduled script crontab examples (not for cloud scripts)
* * * * * * Run every second
* * * * * Run every minute
0 */6 * * * Run once at minute 0 every 6 hours
15 */6 * * * Run once at minute 15 every 6 hours
* once * * * Run once every hour
* * once * * Run once every day
* 10 once * * Run once between 10:00-10:59 each day; if it runs at 10:04, it won't run again that day between 10:05-10:59
* 1,3,5 once * * Run once at 1:00, 3:00, 5:00 each day; if it runs at 1:00, it won't run again at 3:00 or 5:00
* */4 once * * Check and run once every 4 hours; if it runs at 4:00, it won't run again that day at 8:00, 12:00, 16:00, 20:00, 24:00
* 10-23 once * * Run once between 10:00-23:59 each day; if it runs at 10:04, it won't run again that day between 10:05-23:59
* once 13 * * Run once every hour on the 13th day of each month`.replace(/\n/g,"<br>")}},"zh-TW":{title:"繁體中文",thisIsAUserScript:"一個使用者腳本",undefinedPrompt:"未定義的提示符",quickfix:"修復 {0} 問題",addEslintDisableNextLine:"新增 eslint-disable-next-line 註解",addEslintDisable:"新增 eslint-disable 註解",declareGlobal:"將 '{0}' 宣告為全域變數 (/* global */)",prompt:{name:"腳本名稱",namespace:"腳本命名空間",copyright:"腳本的版權資訊",license:"腳本的開源協議",version:"腳本版本",description:"腳本描述",icon:"腳本圖示",iconURL:"腳本圖示",defaulticon:"腳本圖示",icon64:"64x64 大小的腳本圖示",icon64URL:"64x64 大小的腳本圖示",grant:"腳本特殊 Api 權限申請",author:"腳本作者","run-at":"腳本的執行時間<br>`document-start`：在前端匹配到網址後，以最快速度將腳本注入頁面<br>`document-end`：DOM 載入完成後注入腳本，此時頁面腳本與圖像資源可能仍在載入<br>`document-idle`：所有內容載入完成後注入腳本<br>`document-body`：僅在頁面存在 body 元素時才注入腳本","run-in":"腳本注入的環境",homepage:"腳本首頁",homepageURL:"腳本首頁",website:"腳本首頁",background:"背景腳本",include:"腳本匹配 url 執行的頁面",match:"腳本匹配 url 執行的頁面",exclude:"腳本匹配 url 不執行的頁面",connect:"取得網站的存取權限",resource:"引入資源檔案",require:"引入外部 js 檔","require-css":"引入外部 css 檔",noframes:"表示腳本不在 `<frame>` 中執行",compatible:"用於在 GreasyFork 中顯示腳本相容性資訊","inject-into":"腳本注入環境<br>`content`：將腳本注入 content 環境<br>`page`：將腳本注入網頁環境（預設）<br>註：SC 不支援依據 CSP 判斷是否注入 content 環境的 `inject-into: auto`。","early-start":"配合 `run-at: document-start` 使用，`early-start` 可以比網頁更早載入並執行腳本，但可能造成效能問題與 GM API 限制。（SC 獨有）",definition:"RoyExt 特有功能：一個 `.d.ts` 檔案的引用網址，可啟用編輯器自動提示",antifeature:"與腳本市場相關，不受歡迎的功能需要在此描述",updateURL:"腳本檢查更新的 url",downloadURL:"腳本更新的下載網址",supportURL:"支援站點、錯誤回報頁面",source:"腳本原始碼頁面",crontab:`排程腳本 crontab 參考（不適用於雲端腳本）
* * * * * * 每秒執行一次
* * * * * 每分鐘執行一次
0 */6 * * * 每 6 小時的第 0 分執行一次
15 */6 * * * 每 6 小時的第 15 分執行一次
* once * * * 每小時執行一次
* * once * * 每天執行一次
* 10 once * * 每天 10:00-10:59 執行一次，若在 10:04 已執行，當日 10:05-10:59 不再執行
* 1,3,5 once * * 每天 1/3/5 點執行一次，若 1 點已執行，當天 3、5 點不再執行
* */4 once * * 每隔 4 小時檢查並執行一次，若 4 點已執行，當天 8/12/16/20/24 點不再執行
* 10-23 once * * 每天 10:00-23:59 執行一次，若 10:04 已執行，當日 10:05-23:59 不再執行
* once 13 * * 每月 13 號的每小時執行一次`.replace(/\n/g,"<br>")}},"ja-JP":{title:"日本語",thisIsAUserScript:"ユーザースクリプト",undefinedPrompt:"未定義のプロンプト",quickfix:"{0} の問題を修正",addEslintDisableNextLine:"eslint-disable-next-line コメントを追加",addEslintDisable:"eslint-disable コメントを追加",declareGlobal:"'{0}' をグローバル変数として宣言 (/* global */)",prompt:{name:"スクリプト名",namespace:"スクリプトの名前空間",copyright:"スクリプトの著作権情報",license:"スクリプトのライセンス",version:"スクリプトのバージョン",description:"スクリプトの説明",icon:"スクリプトのアイコン",iconURL:"スクリプトのアイコン",defaulticon:"スクリプトのアイコン",icon64:"64x64 サイズのスクリプトアイコン",icon64URL:"64x64 サイズのスクリプトアイコン",grant:"スクリプトが要求する特別な API 権限",author:"スクリプトの作者","run-at":"スクリプトの実行タイミング<br>`document-start`：URL がマッチした直後、できるだけ早くスクリプトを注入<br>`document-end`：DOM 読み込み完了後に注入（画像などは読み込み中の可能性あり）<br>`document-idle`：ページ内のすべての読み込み完了後に注入<br>`document-body`：body 要素が存在する場合のみ注入","run-in":"スクリプトを注入するコンテキスト",homepage:"スクリプトのホームページ",homepageURL:"スクリプトのホームページ",website:"スクリプトのホームページ",background:"バックグラウンドスクリプト",include:"スクリプトを実行する URL パターン",match:"スクリプトを実行する URL パターン",exclude:"スクリプトを実行しない URL パターン",connect:"アクセス権を要求するサイト",resource:"読み込むリソースファイル",require:"読み込む外部 JS ファイル","require-css":"読み込む外部 CSS ファイル",noframes:"スクリプトを `<frame>` 内では実行しない",compatible:"GreasyFork に表示される互換性情報","inject-into":"スクリプトの注入コンテキスト<br>`content`：コンテンツスクリプト環境に注入<br>`page`：ページコンテキストに注入（既定）<br>注：SC は CSP に基づき自動でコンテキストを切り替える `inject-into: auto` には対応していません。","early-start":"`run-at: document-start` と併用します。`early-start` を指定するとページよりも早くスクリプトを実行できますが、パフォーマンスへの影響や GM API の制限が発生する場合があります（SC 独自機能）。",definition:"RoyExt 専用機能：`.d.ts` ファイルの URL。エディタの補完を有効にします。",antifeature:"スクリプトマーケット向け：好まれない機能がある場合、ここに説明を記載します。",updateURL:"スクリプト更新を確認する URL",downloadURL:"スクリプト更新をダウンロードする URL",supportURL:"サポートサイト・バグ報告ページ",source:"スクリプトのソースコードページ",crontab:`スケジュールスクリプトの crontab 例（クラウドスクリプトには非対応）
* * * * * * 毎秒実行
* * * * * 毎分実行
0 */6 * * * 6 時間ごとに 0 分に 1 回実行
15 */6 * * * 6 時間ごとに 15 分に 1 回実行
* once * * * 毎時 1 回実行
* * once * * 毎日 1 回実行
* 10 once * * 毎日 10:00-10:59 の間に 1 回実行。10:04 に実行された場合、その日は 10:05-10:59 に再実行されません
* 1,3,5 once * * 毎日 1/3/5 時に 1 回実行。1 時に実行された場合、その日は 3 時と 5 時に再実行されません
* */4 once * * 4 時間ごとに確認して 1 回実行。4 時に実行された場合、その日は 8/12/16/20/24 時に再実行されません
* 10-23 once * * 毎日 10:00-23:59 の間に 1 回実行。10:04 に実行された場合、その日は 10:05-23:59 に再実行されません
* once 13 * * 毎月 13 日の各時間帯で 1 回実行`.replace(/\n/g,"<br>")}},"de-DE":{title:"Deutsch",thisIsAUserScript:"Ein Benutzerskript",undefinedPrompt:"Undefinierter Prompt",quickfix:"{0}-Problem beheben",addEslintDisableNextLine:"eslint-disable-next-line Kommentar hinzuf\xfcgen",addEslintDisable:"eslint-disable Kommentar hinzuf\xfcgen",declareGlobal:"'{0}' als globale Variable deklarieren (/* global */)",prompt:{name:"Skriptname",namespace:"Skript-Namensraum",copyright:"Urheberrechtsinformationen des Skripts",license:"Open-Source-Lizenz des Skripts",version:"Skriptversion",description:"Skriptbeschreibung",icon:"Skript-Symbol",iconURL:"Skript-Symbol",defaulticon:"Skript-Symbol",icon64:"64x64 Skript-Symbol",icon64URL:"64x64 Skript-Symbol",grant:"Angeforderte spezielle API-Berechtigungen",author:"Skriptautor","run-at":"Zeitpunkt der Skriptausf\xfchrung<br>`document-start`: so fr\xfch wie m\xf6glich nach URL-Match injizieren<br>`document-end`: nach dem Laden des DOM injizieren (Bilder usw. k\xf6nnen noch laden)<br>`document-idle`: nach vollst\xe4ndigem Laden aller Inhalte injizieren<br>`document-body`: nur injizieren, wenn ein body-Element vorhanden ist","run-in":"Kontext, in den das Skript injiziert wird",homepage:"Skript-Homepage",homepageURL:"Skript-Homepage",website:"Skript-Homepage",background:"Hintergrundskript",include:"Seiten-URLs, auf denen das Skript ausgef\xfchrt wird",match:"Seiten-URLs, auf denen das Skript ausgef\xfchrt wird",exclude:"Seiten-URLs, auf denen das Skript nicht ausgef\xfchrt wird",connect:"Websites, auf die das Skript zugreifen darf",resource:"Zu ladende Ressourcendateien",require:"Zu ladende externe JS-Dateien","require-css":"Zu ladende externe CSS-Dateien",noframes:"Skript nicht innerhalb von `<frame>` ausf\xfchren",compatible:"Kompatibilit\xe4tsinformationen f\xfcr GreasyFork","inject-into":"Skript-Injektionskontext<br>`content`: in den Content-Kontext injizieren<br>`page`: in den Seitenkontext injizieren (Standard)<br>Hinweis: SC unterst\xfctzt `inject-into: auto` nicht, bei dem der Kontext \xfcber CSP gew\xe4hlt wird.","early-start":"Wird mit `run-at: document-start` verwendet. `early-start` l\xe4sst das Skript noch vor der Seite laufen, kann aber die Leistung beeintr\xe4chtigen und GM-APIs einschr\xe4nken. (Nur in SC)",definition:"Nur f\xfcr RoyExt: URL zu einer `.d.ts`-Datei f\xfcr Editor-Autovervollst\xe4ndigung",antifeature:"F\xfcr Script-Marktpl\xe4tze: hier unerw\xfcnschte oder kontroverse Funktionen beschreiben",updateURL:"URL zur Aktualisierungspr\xfcfung des Skripts",downloadURL:"URL zum Herunterladen von Skriptaktualisierungen",supportURL:"Support-Seite / Bugtracker",source:"Quellcode-Seite des Skripts",crontab:`Beispiele f\xfcr geplante Skripte (crontab, nicht f\xfcr Cloud-Skripte)
* * * * * * Jede Sekunde ausf\xfchren
* * * * * Jede Minute ausf\xfchren
0 */6 * * * Alle 6 Stunden zur Minute 0 ausf\xfchren
15 */6 * * * Alle 6 Stunden zur Minute 15 ausf\xfchren
* once * * * Einmal pro Stunde ausf\xfchren
* * once * * Einmal pro Tag ausf\xfchren
* 10 once * * Einmal t\xe4glich zwischen 10:00-10:59; wenn um 10:04 ausgef\xfchrt, an diesem Tag nicht erneut zwischen 10:05-10:59
* 1,3,5 once * * Einmal t\xe4glich um 1:00, 3:00, 5:00; wenn um 1:00 ausgef\xfchrt, an diesem Tag nicht erneut um 3:00 oder 5:00
* */4 once * * Alle 4 Stunden pr\xfcfen und einmal ausf\xfchren; wenn um 4:00 ausgef\xfchrt, an diesem Tag nicht erneut um 8:00, 12:00, 16:00, 20:00, 24:00
* 10-23 once * * Einmal t\xe4glich zwischen 10:00-23:59; wenn um 10:04 ausgef\xfchrt, an diesem Tag nicht erneut zwischen 10:05-23:59
* once 13 * * Einmal st\xfcndlich am 13. Tag jedes Monats ausf\xfchren`.replace(/\n/g,"<br>")}},"vi-VN":{title:"Tiếng Việt",thisIsAUserScript:"Một user script",undefinedPrompt:"Prompt chưa được định nghĩa",quickfix:"Sửa lỗi {0}",addEslintDisableNextLine:"Th\xeam ch\xfa th\xedch eslint-disable-next-line",addEslintDisable:"Th\xeam ch\xfa th\xedch eslint-disable",declareGlobal:"Khai b\xe1o '{0}' l\xe0 biến to\xe0n cục (/* global */)",prompt:{name:"T\xean script",namespace:"Namespace của script",copyright:"Th\xf4ng tin bản quyền của script",license:"Giấy ph\xe9p m\xe3 nguồn mở của script",version:"Phi\xean bản script",description:"M\xf4 tả script",icon:"Biểu tượng script",iconURL:"Biểu tượng script",defaulticon:"Biểu tượng script",icon64:"Biểu tượng script k\xedch thước 64x64",icon64URL:"Biểu tượng script k\xedch thước 64x64",grant:"Quyền API đặc biệt m\xe0 script y\xeau cầu",author:"T\xe1c giả script","run-at":"Thời điểm chạy script<br>`document-start`: ch\xe8n script sớm nhất c\xf3 thể sau khi khớp URL<br>`document-end`: ch\xe8n sau khi DOM tải xong (ảnh v.v. c\xf3 thể vẫn đang tải)<br>`document-idle`: ch\xe8n sau khi to\xe0n bộ nội dung đ\xe3 tải xong<br>`document-body`: chỉ ch\xe8n khi trang c\xf3 phần tử body","run-in":"Ngữ cảnh m\xe0 script được ch\xe8n v\xe0o",homepage:"Trang chủ script",homepageURL:"Trang chủ script",website:"Trang chủ script",background:"Script nền (background)",include:"Trang c\xf3 URL khớp v\xe0 chạy script",match:"Trang c\xf3 URL khớp v\xe0 chạy script",exclude:"Trang c\xf3 URL khớp nhưng KH\xd4NG chạy script",connect:"Trang web m\xe0 script được ph\xe9p truy cập",resource:"Tệp t\xe0i nguy\xean được import",require:"Tệp JS b\xean ngo\xe0i được import","require-css":"Tệp CSS b\xean ngo\xe0i được import",noframes:"Kh\xf4ng chạy script b\xean trong `<frame>`",compatible:"Th\xf4ng tin tương th\xedch hiển thị tr\xean GreasyFork","inject-into":"Ngữ cảnh ch\xe8n script<br>`content`: ch\xe8n v\xe0o ngữ cảnh content<br>`page`: ch\xe8n v\xe0o ngữ cảnh trang (mặc định)<br>Lưu \xfd: SC kh\xf4ng hỗ trợ `inject-into: auto`, lựa chọn ngữ cảnh dựa tr\xean CSP.","early-start":"D\xf9ng c\xf9ng với `run-at: document-start`. `early-start` cho ph\xe9p script chạy sớm hơn cả trang, nhưng c\xf3 thể g\xe2y ảnh hưởng hiệu năng v\xe0 giới hạn một số GM API. (Chỉ c\xf3 trong SC)",definition:"T\xednh năng ri\xeang của RoyExt: URL tới tệp `.d.ts` gi\xfap bật gợi \xfd tự động trong tr\xecnh soạn thảo",antifeature:"D\xf9ng cho chợ script: m\xf4 tả c\xe1c t\xednh năng kh\xf4ng được người d\xf9ng ưa th\xedch",updateURL:"URL d\xf9ng để kiểm tra cập nhật script",downloadURL:"URL tải về bản cập nhật script",supportURL:"Trang hỗ trợ / b\xe1o lỗi",source:"Trang m\xe3 nguồn script",crontab:`V\xed dụ crontab cho script chạy định kỳ (kh\xf4ng \xe1p dụng cho script tr\xean cloud)
* * * * * * Chạy mỗi gi\xe2y
* * * * * Chạy mỗi ph\xfat
0 */6 * * * Chạy 1 lần v\xe0o ph\xfat 0 mỗi 6 giờ
15 */6 * * * Chạy 1 lần v\xe0o ph\xfat 15 mỗi 6 giờ
* once * * * Chạy 1 lần mỗi giờ
* * once * * Chạy 1 lần mỗi ng\xe0y
* 10 once * * Chạy 1 lần mỗi ng\xe0y trong khoảng 10:00-10:59; nếu chạy l\xfac 10:04 th\xec h\xf4m đ\xf3 kh\xf4ng chạy lại trong 10:05-10:59
* 1,3,5 once * * Chạy 1 lần l\xfac 1:00, 3:00, 5:00 mỗi ng\xe0y; nếu chạy l\xfac 1:00 th\xec h\xf4m đ\xf3 kh\xf4ng chạy lại l\xfac 3:00 hoặc 5:00
* */4 once * * Kiểm tra v\xe0 chạy 1 lần mỗi 4 giờ; nếu chạy l\xfac 4:00 th\xec h\xf4m đ\xf3 kh\xf4ng chạy lại l\xfac 8:00, 12:00, 16:00, 20:00, 24:00
* 10-23 once * * Chạy 1 lần mỗi ng\xe0y trong khoảng 10:00-23:59; nếu chạy l\xfac 10:04 th\xec h\xf4m đ\xf3 kh\xf4ng chạy lại trong 10:05-23:59
* once 13 * * Chạy 1 lần mỗi giờ v\xe0o ng\xe0y 13 hằng th\xe1ng`.replace(/\n/g,"<br>")}},"ru-RU":{title:"Русский",thisIsAUserScript:"Пользовательский скрипт",undefinedPrompt:"Неопределённый промпт",quickfix:"Исправить проблему {0}",addEslintDisableNextLine:"Добавить комментарий eslint-disable-next-line",addEslintDisable:"Добавить комментарий eslint-disable",declareGlobal:"Объявить '{0}' как глобальную переменную (/* global */)",prompt:{name:"Имя скрипта",namespace:"Пространство имён скрипта",copyright:"Информация об авторских правах скрипта",license:"Лицензия с открытым исходным кодом",version:"Версия скрипта",description:"Описание скрипта",icon:"Иконка скрипта",iconURL:"Иконка скрипта",defaulticon:"Иконка скрипта",icon64:"Иконка скрипта 64x64",icon64URL:"Иконка скрипта 64x64",grant:"Запрашиваемые специальные права доступа к API",author:"Автор скрипта","run-at":"Момент запуска скрипта<br>`document-start`: внедрить как можно раньше после совпадения URL<br>`document-end`: внедрить после загрузки DOM (изображения и др. могут ещё загружаться)<br>`document-idle`: внедрить после полной загрузки содержимого<br>`document-body`: внедрить только если на странице есть элемент body","run-in":"Контекст, в который внедряется скрипт",homepage:"Домашняя страница скрипта",homepageURL:"Домашняя страница скрипта",website:"Домашняя страница скрипта",background:"Фоновый скрипт",include:"Страницы, на которых скрипт выполняется (совпадение URL)",match:"Страницы, на которых скрипт выполняется (совпадение URL)",exclude:"Страницы, на которых скрипт НЕ выполняется (совпадение URL)",connect:"Сайты, к которым скрипт может обращаться",resource:"Подключаемые ресурсные файлы",require:"Подключаемые внешние JS-файлы","require-css":"Подключаемые внешние CSS-файлы",noframes:"Не запускать скрипт внутри `<frame>`",compatible:"Информация о совместимости, отображаемая на GreasyFork","inject-into":"Контекст внедрения скрипта<br>`content`: внедрить в контекст content<br>`page`: внедрить в контекст страницы (по умолчанию)<br>Примечание: SC не поддерживает `inject-into: auto`, когда контекст выбирается по CSP.","early-start":"Используется совместно с `run-at: document-start`. `early-start` позволяет выполнять скрипт раньше загрузки страницы, но может ухудшать производительность и ограничивать некоторые GM API. (Только в SC)",definition:"Особенность RoyExt: URL файла `.d.ts`, используемого для автодополнения в редакторе",antifeature:"Для маркетплейсов скриптов: опишите здесь нежелательные / спорные функции",updateURL:"URL для проверки обновлений скрипта",downloadURL:"URL для загрузки обновлений скрипта",supportURL:"Страница поддержки / отчёта об ошибках",source:"Страница с исходным кодом скрипта",crontab:`Примеры crontab для планового запуска скриптов (не для облачных скриптов)
* * * * * * Запуск каждую секунду
* * * * * Запуск каждую минуту
0 */6 * * * Запуск раз в 6 часов в 00 минут
15 */6 * * * Запуск раз в 6 часов в 15 минут
* once * * * Запуск раз в час
* * once * * Запуск раз в день
* 10 once * * Запуск раз в день между 10:00-10:59; если выполнен в 10:04, в этот день не запустится снова между 10:05-10:59
* 1,3,5 once * * Запуск раз в день в 1:00, 3:00, 5:00; если выполнен в 1:00, в этот день не запустится в 3:00 и 5:00
* */4 once * * Проверка и запуск раз в 4 часа; если выполнен в 4:00, в этот день не запустится в 8:00, 12:00, 16:00, 20:00, 24:00
* 10-23 once * * Запуск раз в день между 10:00-23:59; если выполнен в 10:04, в этот день не запустится снова между 10:05-23:59
* once 13 * * Запуск каждый час в течение 13-го числа месяца`.replace(/\n/g,"<br>")}}};function d(){window.MonacoEnvironment={getWorkerUrl:(e,t)=>"typescript"===t||"javascript"===t?"/src/ts.worker.js":"/src/editor.worker.js"};let e=c["en-US"],t=t=>{let r=(t=t||"")&&(t in c?t:"en-US")||"en-US";e=c[r]};l.then(e=>{t(e)}),n.EO.addListener("language",e=>{t(e)});let r=/\/\/[ \t]*@(\S+)[ \t]*(.*)$/;o.eo.registerHoverProvider("javascript",{provideHover:(t,n)=>new Promise(i=>{let o=t.getLineContent(n.lineNumber),s=r.exec(o);if(s){let t=s[1];i({contents:[{value:e.prompt[t]||e.undefinedPrompt,supportHtml:!0}]})}else i(/==UserScript==/.test(o)?{contents:[{value:e.thisIsAUserScript}]}:null)})}),o.eo.registerCodeActionProvider("javascript",{provideCodeActions:(t,r,i)=>{let o=[],a=n.Eb.get("eslint-fix");for(let r=0;r<i.markers.length;r+=1){let n=i.markers[r],l="string"==typeof n.code?n.code:n.code.value,c=a.get(`${l}|${n.startLineNumber}|${n.endLineNumber}|${n.startColumn}|${n.endColumn}`);if(c){let r={resource:t.uri,textEdit:{range:c.range,text:c.text},versionId:void 0};o.push({title:e.quickfix.replace("{0}",`${l}`),diagnostics:[n],kind:"quickfix",edit:{edits:[r]},isPreferred:!0})}if("no-undef"===l){let r=(n.message||"").match(/^[^']*'([^']+)'[^']*$/),i=r&&r[1];if(i){let r,{insertLine:a,globalLine:l}=(0,s.IK)(t);if(null!=l){let e=t.getLineContent(l),n=(0,s.Gh)(e,i);r={range:{startLineNumber:l,startColumn:1,endLineNumber:l,endColumn:e.length+1},text:n}}else r={range:{startLineNumber:a,startColumn:1,endLineNumber:a,endColumn:1},text:`/* global ${i} */
`};o.push({title:e.declareGlobal.replace("{0}",i),diagnostics:[n],kind:"quickfix",edit:{edits:[{resource:t.uri,textEdit:r,versionId:void 0}]},isPreferred:!1})}}o.push({title:e.addEslintDisableNextLine,diagnostics:[n],kind:"quickfix",edit:{edits:[{resource:t.uri,textEdit:{range:{startLineNumber:n.startLineNumber,endLineNumber:n.startLineNumber,startColumn:1,endColumn:1},text:`// eslint-disable-next-line ${"string"==typeof n.code?n.code:n.code.value}
`},versionId:void 0}]},isPreferred:!0}),o.push({title:e.addEslintDisable,diagnostics:[n],kind:"quickfix",edit:{edits:[{resource:t.uri,textEdit:{range:{startLineNumber:1,endLineNumber:1,startColumn:1,endColumn:1},text:`/* eslint-disable ${"string"==typeof n.code?n.code:n.code.value} */
`},versionId:void 0}]},isPreferred:!0})}return{actions:o,dispose:()=>{}}}}),Promise.all([n.EO.getEditorConfig(),n.EO.getEditorTypeDefinition()]).then(([e,t])=>{let r=JSON.parse(e);o.eo.typescript.javascriptDefaults.setCompilerOptions({allowNonTsExtensions:!0,...r}),o.eo.typescript.javascriptDefaults.addExtraLib(t,"scriptcat.d.ts")})}class u{static hook=new i.A;static sendLinterMessage(e){a.postMessage(e)}}a.onmessage=e=>{u.hook.emit("message",e.data)}},80993(e,t,r){"use strict";r.d(t,{Gh:()=>i,IK:()=>n});let n=e=>{let t=e.getLineCount(),r=1,n=null,i=1;for(;i<=t;){let o=e.getLineContent(i).trim();if(""===o||o.startsWith("//")){i+=1;continue}if(o.startsWith("/*")){for(/^\/\*\s*global\b/.test(o)&&(n=i);i<=t&&!e.getLineContent(i).includes("*/");)i+=1;i+=1;continue}r=i;break}return r>t&&(r=t+1),{insertLine:r,globalLine:n}},i=(e,t)=>{if(RegExp("(?:^|[\\s,]|global\\s+)"+t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"(?=[\\s,]|\\*/|$)").test(e))return e;let r=e.lastIndexOf("*/");if(-1===r)return e+", "+t;let n=e.slice(0,r).trimEnd(),i=e.slice(r),o=!/global\s*$/.test(n)&&!/[, ]$/.test(n);return n+(o?", ":" ")+t+" "+i}},26861(e,t,r){"use strict";if(r.d(t,{SU:()=>m,jR:()=>h,jo:()=>g}),!/^(3295|5357|5788)$/.test(r.j))var n=r(16345);if(!/^(3295|5357|5788)$/.test(r.j))var i=r(7068);if(6905==r.j)var o=r(76180);if(!/^(3295|5357|5788)$/.test(r.j))var s=r(59886);if(!/^(3295|5357|5788)$/.test(r.j))var a=r(67069);if(!/^(3295|5357|5788)$/.test(r.j))var l=r(40403);if(!/^(3295|5357|5788)$/.test(r.j))var c=r(77939);let d=/\/\/[ \t]*==User(Script|Subscribe)==([\s\S]+?)\/\/[ \t]*==\/User\1==/m,u=/\/\/[ \t]*@(\S+)[ \t]*(.*)$/gm;function h(e){let t,r,n=!1;if(!(r=d.exec(e)))return null;n="Subscribe"===r[1],t=r[2];let i={};for(u.lastIndex=0;null!==(r=u.exec(t));){let e=r[1].toLowerCase(),t=r[2]?.trim()??"";(i[e]||(i[e]=[])).push(t)}return!i.name||Object.keys(i).length<3?null:(i.namespace||(i.namespace=[""]),n&&(i.usersubscribe=[]),i)}async function p(e){let t=await fetch(e,{headers:{"Cache-Control":"no-cache"}});if(200!==t.status)throw Error("fetch script info failed");if(t.headers.get("content-type")?.includes("text/html"))throw Error("url is html");return await (0,c.mj)(t,t.headers.get("content-type"))}async function g(e,t,r,o=!1,c,d){let u,m;c=c??new i.g0;let f=function(e,t,r){let o=h(e);if(!o)throw Error((0,l.t)("error_metadata_invalid"));if(!o.name?.[0])throw Error((0,l.t)("error_script_name_required"));if(void 0===o.namespace)throw Error((0,l.t)("error_script_namespace_required"));let c=i.$Q;if(void 0!==o.crontab){c=i.Fp;try{(0,s.xG)(o.crontab[0])}catch{throw Error((0,l.t)("error_cron_invalid",{expr:o.crontab[0]}))}}else void 0!==o.background&&(c=i.OY);let d="",u="",p=t;o.updateurl&&o.downloadurl?([u]=o.updateurl,[p]=o.downloadurl):u=t.replace("user.js","meta.js"),(t.startsWith("http://")||t.startsWith("https://"))&&(d=new URL(t).hostname);let g=r||(0,n.g)(),m=(0,a.B)(e),f=Date.now();return{uuid:g,name:o.name[0],author:o.author&&o.author[0],namespace:o.namespace[0],originDomain:d,origin:t,checkUpdate:!0,checkUpdateUrl:u,downloadUrl:p,config:m,metadata:o,selfMetadata:{},sort:-1,type:c,status:i.Ey,runStatus:i.Pk,createtime:f,updatetime:f,checktime:f}}(e,t,r);if(r&&(u=await c.get(r)),u||r&&!o||(u=await c.findByNameAndNamespace(f.name,f.namespace)),!u&&d?.byWebRequest){let e=await c.searchExistingScript(f);if(1===e.length){let t=e[0]?.checkUpdateUrl;if(t)try{let r=await p(t),n=r?h(r):null;n&&n.name[0]===f.name&&(n.namespace?.[0]||"")===f.namespace&&(u=e[0])}catch{}}}let y=e=>e?.grant?.includes("none")&&e?.grant?.some(e=>e.startsWith("GM")),b=e=>{if(e){for(let t of Object.values(e))if(t&&new Set(t).size!==t.length)return!0}};if(d?.byEditor&&y(f.metadata)&&(!u||!y(u.metadata)))throw Error((0,l.t)("error_grant_conflict"));if(d?.byEditor&&b(f.metadata)&&(!u||!b(u.metadata)))throw Error((0,l.t)("error_metadata_line_duplicated"));if(u){if(u.type===i.$Q&&f.type!==i.$Q||f.type===i.$Q&&u.type!==i.$Q)throw Error((0,l.t)("error_script_type_mismatch"));let e=await new i.h8().get(u.uuid);if(!e)throw Error((0,l.t)("error_old_script_code_missing"));m=e;let{uuid:t,createtime:r,lastruntime:n,error:o,sort:s,selfMetadata:a,subscribeUrl:c,checkUpdate:d,status:h}=u;Object.assign(f,{uuid:t,createtime:r,lastruntime:n,error:o,sort:s,selfMetadata:a||{},subscribeUrl:c,checkUpdate:d,status:h})}else f.type===i.$Q&&(f.status=i.fn),f.checktime=Date.now();return{script:f,oldScript:u,oldScriptCode:m?.code}}async function m(e,t){let r=new o.T9,n=h(e);if(!n)throw Error((0,l.t)("error_metadata_invalid"));if(void 0===n.name)throw Error((0,l.t)("error_subscribe_name_required"));let i=Date.now(),s={url:t,name:n.name[0],code:e,author:n.author&&n.author[0]||"",scripts:{},metadata:n,status:o.Gw,createtime:i,updatetime:i,checktime:i},a=await r.findByUrl(t);if(a){let{url:e,scripts:t,createtime:r,status:n}=a;Object.assign(s,{url:e,scripts:t,createtime:r,status:n})}return{subscribe:s,oldSubscribe:a}}},61301(e,t,r){"use strict";function n(e,t){return Math.floor(Math.random()*(t-e+1))+e}function i(){return`-${Date.now().toString(36)}.${n(8e11,2e12).toString(36)}`}function o(){return"u">typeof mozInnerScreenX}function s(e){switch(typeof e){case"string":case"number":case"boolean":case"object":return typeof e;default:return"unknown"}}function a(e){if(""===e)return;let t=e[0],r=e.substring(1);switch(t){case"b":return"true"===r;case"n":return parseFloat(r);case"o":try{return JSON.parse(r)}catch{return e}case"s":return r;default:return e}}async function l(){let[e]=await chrome.tabs.query({active:!0,lastFocusedWindow:!0});if(!e?.discarded)return e}function c(e){return new Promise(t=>{setTimeout(t,e)})}function d(e){let t=e.metadata?.storagename;return t?t[0]:e.uuid}async function u(){if(chrome.extension.inIncognitoContext)return!0;try{if(chrome.userScripts,"function"!=typeof chrome.userScripts?.getScripts)return!1;let e=await chrome.userScripts.getScripts({ids:["scriptcat-content","scriptcat-inject"]});if(!e||"object"!=typeof e||"number"!=typeof e.length)return!1;if(e[0]?.id)return!0;{let e=`undefined-id-${Date.now()}`;return await chrome.userScripts.register([{id:e,js:[{code:"void 0;"}],matches:["https://not-found.scriptcat.org/"],world:"USER_SCRIPT"}]),await chrome.userScripts.unregister({ids:[e]}),!0}}catch(e){return console.error("checkUserScriptsAvailable error:",e),!1}}r.d(t,{B$:()=>u,Cb:()=>k,Im:()=>n,L4:()=>d,Sk:()=>f,Z5:()=>i,_x:()=>s,bw:()=>l,dZ:()=>p,fY:()=>w,fx:()=>g,gm:()=>o,hy:()=>x,i:()=>y,mt:()=>a,sn:()=>S,v6:()=>_,wI:()=>b,xM:()=>m,yy:()=>c,z3:()=>j,zr:()=>v});var h,p=5788==r.j?((h={})[h.Edge=2]="Edge",h[h.Chrome=1]="Chrome",h[h.chromeA=4]="chromeA",h[h.chromeB=8]="chromeB",h[h.chromeC=16]="chromeC",h[h.edgeA=32]="edgeA",h):null;function g(){let e={firefox:0,webkit:0,chrome:0,unknown:0,chromeVersion:0};if(o())e.firefox=1;else if("object"==typeof webkitIndexedDB)e.webkit=1;else if("function"==typeof webkitRequestAnimationFrame){let t=navigator.userAgent.includes("Edg/"),r=function(){try{return Number(navigator.userAgent.match(/(Chrome|Chromium)\/([0-9]+)/)?.[2])}catch(e){return console.error("Error getting browser version:",e),0}}();e.chrome|=t?2:1,e.chrome|=4*(r<120),e.chrome|=r<138?8:16,t&&(e.chrome|=32*(r>=144)),e.chromeVersion=r}else e.unknown=1;return e}let m=(e,t)=>{if("function"!=typeof URL?.createObjectURL){if(!t)throw Error("URL.createObjectURL is not supported");return t(e)}{let t=URL.createObjectURL(e.blob);return e.persistence||setTimeout(()=>{URL.revokeObjectURL(t)},6e4),t}};function f(e){return new Promise(t=>{let r=new FileReader;r.onloadend=function(){t(this.result)},r.readAsDataURL(e)})}function y(e){let t=e.split(",")[0].split(":")[1].split(";")[0],r=atob(e.split(",")[1]),n=new Uint8Array(new ArrayBuffer(r.length));for(let e=0;e<r.length;e+=1)n[e]=r.charCodeAt(e);return new Blob([n],{type:t})}function b(e){return btoa(encodeURIComponent(e).replace(/%([0-9A-F]{2})/g,(e,t)=>String.fromCharCode(parseInt(`0x${t}`,16))))}function x(e){let t=e.indexOf("==UserScript=="),r=e.indexOf("==/UserScript==");return -1===t||-1===r?null:`// ${e.substring(t,r+15)}`}function v(e){let t=e.indexOf("==UserConfig=="),r=e.indexOf("==/UserConfig==");return -1===t||-1===r?null:`/* ${e.substring(t,r+15)} */`}let w=e=>e?e.split(`
`).map(e=>e.trim()).filter(e=>e):[];function k(e){return e.replace(/^[a-z]|_([a-z])/g,(e,t=e)=>t.toUpperCase())}let j=(e,t=2)=>{if(0===e)return"0 B";let r=Math.floor(Math.log(e)/Math.log(1024)),n=e/Math.pow(1024,r);return`${n.toFixed(t)} ${["B","KB","MB","GB","TB"][r]}`},_=e=>{if(!e)return"";let t="";return e.split(`
`).forEach(e=>{let r=e.indexOf(":");if(r>0){let n=e.substring(0,r),i=e.substring(r+1).trim();t+=`${n}:${i}\r
`}}),t.substring(0,t.length-2)},S=e=>{let t=new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate()));t.setUTCDate(t.getUTCDate()+4-(t.getUTCDay()||7));let r=new Date(Date.UTC(t.getUTCFullYear(),0,1));return Math.ceil(((t.getTime()-r.getTime())/864e5+1)/7)}},16345(e,t,r){"use strict";r.d(t,{g:()=>i});var n=r(53594);let i="function"==typeof crypto.randomUUID?crypto.randomUUID.bind(crypto):n.A},67069(e,t,r){"use strict";r.d(t,{B:()=>i});var n=r(58695);function i(e){let t=/\/\*\s*==UserConfig==([\s\S]+?)\s*==\/UserConfig==\s*\*\//m.exec(e);if(!t)return;let r=t[1].trim().split(/[-]{3,}/),i={},o=new Set;for(let e of r){let t=(0,n.qg)(e);if(t&&"object"==typeof t)for(let[e,r]of Object.entries(t)){if(!r||"object"!=typeof r)throw Error(`UserConfig group "${e}" is not a valid object.`);i[e]=r,"#options"!==e&&(o.add(e),Object.keys(i[e]||{}).forEach((t,r)=>{let n=i[e];n[t]&&"object"==typeof n[t]&&(n[t].index=n[t].index||r)}))}}return i["#options"]={sort:Array.from(o)},i}},8330(e){"use strict";e.exports={rE:"1.3.2"}}}]);